"""sub05: sub04 + minGRU members (stack of minGRU layers, train/train_gru.py MinGRUNet), all in Numba, one row at a time.
  minGRU step per layer: LayerNorm -> Linear(H, 2H) -> gate z = sigmoid(k), candidate g(c) = c + 0.5 (c >= 0) or
  sigmoid(c) -> h = (1 - z) h + z g(c) -> u += h -> u += MLP(LayerNorm(u)) (H -> 2H GELU -> H); head on u; D/C output.
  The input projection is updated incrementally (only changed input columns), as for the GRUs. evt2 / trees are skipped
  when the package has no corrector.
(sub04 notes follow)
sub04: ensemble (+ optional error-correction model), all in Numba, one row at a time.
  New in sub04: GRUs can use the 'reg' input set (train/features.py: hygiene-cleaned raw + one-row differences + flags +
  regime rates + volume vs EMA + volume since the last mid event), streamed by reg_row(); weights.npz "gru_feats" gives
  each GRU's input set (0 = raw_d1, 1 = reg). The corrector is used only if its trees are non-empty.

  GRUs : N x (2x128 GRU on raw_d1 inputs: raw 112 + one-row differences + 5 missing flags; D/C head), listed in
         weights.npz "gru_names" (sub03: gru-auxmid-s0, gru-no-d1-s0, gru-aux05-s0; hidden inputs of gru-no-d1-s0 are
         folded into its input weights as zeros; auxiliary training heads are not used at prediction time)
  W1D  : memory-free MLP on 864 causal formula features (long640 + z-scores over 100 / 1000 rows) = win-z-s0
  base : ridge stack of the N + 1 predictions (per target)
  corr : LightGBM trees (exported to arrays) on [the N + 1 predictions, 52 evt2 event-time features], added to base
Output = (base + corr) * scale, scale fitted so predictions stay inside the metric clip.
All weights / constants are in weights.npz (built by submissions/build_sub03.py).
"""
from pathlib import Path
import os
os.environ.setdefault("OMP_NUM_THREADS", "1"); os.environ.setdefault("NUMBA_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1"); os.environ.setdefault("MKL_NUM_THREADS", "1")
import math
import numpy as np
from numba import njit, types
from numba.typed import Dict
from numba.extending import overload
import ctypes, hashlib, subprocess, tempfile

HERE = Path(__file__).resolve().parent

# CKERN: the scorer image has gcc (build-essential). At load, a tiny C matvec is compiled for THIS CPU (-march=native):
# int8 weights x 15-bit integer activations, int32 sums (vectorises to pmaddwd / VNNI, which Numba cannot emit): ~1.4x
# faster than the Numba loop for the minGRU gate / MLP matrices, relative error ~1e-4 (int8 weights alone ~1e-2). It is
# called from inside the compiled kernel (no Python call per row). Any failure -> the Numba kernel, unchanged.
_C_SRC = r"""
// VNNI-packed int8 matvec for the minGRU members: a drop-in for the shipped mv_u8 (same signature, same int32 sums,
// same float epilogue expression). Path picked at COMPILE time from -march=native (the .so is built on the scoring CPU);
// -DFORCE_PATH=n forces a lower path so the fallbacks can be tested on the desktop.
//   3: AVX-512 VNNI  vpdpbusd zmm, 16 rows x 4 inputs per 64-byte load, 4 row blocks (64 rows) per pass
//   2: AVX-VNNI      vpdpbusd ymm (VEX), 8 rows x 4 inputs, 32 rows per pass
//   1: AVX2          sign trick: maddubs(|w|, sign(q, w)) + madd(1) - exact (pair sums <= 2*128*127 < 32767, no saturation)
//   0: scalar        same packed layout, plain C
// Exactness: all int32 sums are exact in any order (|sum| <= 384*127*255 < 2^24), so S equals mv_u8's (s - 128*rs)
// exactly; (float)S is exact; the epilogue is the same C expression as mv_u8.
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#if defined(__x86_64__) || defined(__i386__)
#include <immintrin.h>
#endif

#if defined(__AVX512F__) && defined(__AVX512BW__) && defined(__AVX512VNNI__)
#define NATIVE_PATH 3
#elif defined(__AVXVNNI__)
#define NATIVE_PATH 2
#elif defined(__AVX2__)
#define NATIVE_PATH 1
#else
#define NATIVE_PATH 0
#endif
#ifdef FORCE_PATH
#define PATH FORCE_PATH
#else
#define PATH NATIVE_PATH
#endif
#if PATH > NATIVE_PATH
#error "FORCE_PATH is above what this -march supports"
#endif
#if PATH == 2 && !defined(__AVXVNNI__)
#error "path 2 needs AVX-VNNI"
#endif
#define NB (PATH == 3 ? 16 : 8)   /* output rows per vector */
#define RB 4                      /* row blocks per pass (activation broadcast reused RB times) */
#define G (NB * RB)               /* rows per pass */
#define SIGNED_ACT (PATH <= 1)    /* paths 0/1: q in [-127,127], no offset; paths 2/3: q+128 as u8 and row sums */
#define MAXC 8192

int mvp_path(void) { return PATH; }

/* ------------------------------------------------------------------ reference: the shipped mv_u8, verbatim logic */
typedef struct { const int8_t* W; long ldw; int R, C; int8_t first, last; int32_t* rs; } RSE;
static RSE RTAB[256]; static int RNT = 0;
static uint8_t RXU[MAXC];
static const int32_t* ref_rowsums(const int8_t* W, long ldw, int R, int C) {
    for (int k = 0; k < RNT; k++) { RSE* e = &RTAB[k];
        if (e->W == W && e->ldw == ldw && e->R == R && e->C == C && e->first == W[0] && e->last == W[(long)(R - 1) * ldw + C - 1]) return e->rs; }
    int32_t* rs = (int32_t*)malloc(sizeof(int32_t) * R);
    for (int i = 0; i < R; i++) { const int8_t* w = W + (long)i * ldw; int32_t t = 0; for (int j = 0; j < C; j++) t += w[j]; rs[i] = t; }
    if (RNT < 256) { RSE e = { W, ldw, R, C, W[0], W[(long)(R - 1) * ldw + C - 1], rs }; RTAB[RNT++] = e; }
    return rs;
}
void mv_u8_ref(const int8_t* W, long ldw, const float* sc, const float* x, const float* b, float* out, int R, int C) {
    const int32_t* rs = ref_rowsums(W, ldw, R, C);
    float m = 1e-12f; for (int j = 0; j < C; j++) { float a = fabsf(x[j]); if (a > m) m = a; }
    float sx = m / 127.f, inv = 1.f / sx; for (int j = 0; j < C; j++) RXU[j] = (uint8_t)(lrintf(x[j] * inv) + 128);
    for (int i = 0; i < R; i++) { const int8_t* w = W + (long)i * ldw; int32_t s = 0;
        for (int j = 0; j < C; j++) s += (int32_t)w[j] * (int32_t)RXU[j];
        out[i] = b[i] + sc[i] * (sx * (float)(s - 128 * rs[i])); }
}
void mv_u8_raw(const int8_t* W, long ldw, const float* x, int32_t* S, int R, int C) {   /* int32 (s - 128 rs) for exactness tests */
    const int32_t* rs = ref_rowsums(W, ldw, R, C);
    float m = 1e-12f; for (int j = 0; j < C; j++) { float a = fabsf(x[j]); if (a > m) m = a; }
    float sx = m / 127.f, inv = 1.f / sx; for (int j = 0; j < C; j++) RXU[j] = (uint8_t)(lrintf(x[j] * inv) + 128);
    for (int i = 0; i < R; i++) { const int8_t* w = W + (long)i * ldw; int32_t s = 0;
        for (int j = 0; j < C; j++) s += (int32_t)w[j] * (int32_t)RXU[j];
        S[i] = s - 128 * rs[i]; }
}

/* ------------------------------------------------------------------ packed weights, cached by (address, shape) */
/* layout: [group g = R/G][k4 = C/4][rb < RB][r < NB][t < 4]  -> one contiguous 4*G-byte chunk per k4 per group */
typedef struct { const int8_t* W; long ldw; int R, C; int8_t f, l, mid; int Rp, K4, q4; int8_t* P; int32_t* rs; } PK;
static PK TAB[256]; static int NT = 0, LASTK = -1;

#include <sys/mman.h>
static char* ARENA = NULL; static size_t AOFF = 0, ASZ = (size_t)8 << 20;   /* CACHE: 8 MB arena, 2 MB aligned, huge pages */
static void* amalloc(size_t n) {
    n = (n + 63) & ~(size_t)63;
    if (!ARENA) { void* p = NULL; if (posix_memalign(&p, (size_t)2 << 20, ASZ) == 0) { ARENA = (char*)p; memset(ARENA, 0, ASZ); madvise(ARENA, ASZ, MADV_HUGEPAGE); } else ASZ = 0; }
    if (ARENA && AOFF + n <= ASZ) { void* r = ARENA + AOFF; AOFF += n; return r; }
    void* p = NULL; if (posix_memalign(&p, 64, n)) return NULL; memset(p, 0, n); return p;
}
#define free(p) ((void)0)   /* arena blocks are never freed (packed weights live for the process) */

static PK* lookup(const int8_t* W, long ldw, int R, int C) {
    const int8_t l = W[(long)(R - 1) * ldw + C - 1], mid = W[(long)(R / 2) * ldw + C / 2];
    for (int s = 0; s < NT; s++) {       /* calls come in a fixed cycle: start at the slot after the last hit -> O(1) */
        int i = (LASTK + 1 + s) % NT; PK* e = &TAB[i];
        if (e->W == W && e->ldw == ldw && e->R == R && e->C == C && e->f == W[0] && e->l == l && e->mid == mid) { LASTK = i; return e; }
    }
    if (NT >= 256) return NULL;
    PK* e = &TAB[NT];
    e->W = W; e->ldw = ldw; e->R = R; e->C = C; e->f = W[0]; e->l = l; e->mid = mid;
    e->K4 = (C + 3) / 4; e->Rp = (R + G - 1) / G * G;
    int q4 = 1;   /* Q4K: the int4 grid (-7..7) in int8 containers -> nibbles */
    for (int i = 0; i < R && q4; i++) for (int j = 0; j < C; j++) { int8_t w = W[(long)i * ldw + j]; if (w > 7 || w < -7) { q4 = 0; break; } }
    e->q4 = q4;
    if (q4) {
        e->P = (int8_t*)amalloc((size_t)e->Rp * e->K4 * 2); e->rs = (int32_t*)amalloc(sizeof(int32_t) * (size_t)e->Rp);
        if (!e->P || !e->rs) return NULL;
        memset(e->P, 0x88, (size_t)e->Rp * e->K4 * 2);   /* nibble 8 = weight 0 (padding rows / inputs) */
        for (int i = 0; i < R; i++) {
            size_t g = i / G, rr = i % G, rb = rr / NB, r = rr % NB; int32_t t = 0;
            for (int j = 0; j < C; j++) { int8_t w = W[(long)i * ldw + j]; t += w;
                uint8_t* b = (uint8_t*)e->P + (((g * e->K4 + (size_t)(j >> 2)) * (RB / 2) + (rb >> 1)) * NB + r) * 4 + (j & 3);
                *b = (rb & 1) ? (uint8_t)((*b & 0x0F) | ((w + 8) << 4)) : (uint8_t)((*b & 0xF0) | (w + 8)); }
            e->rs[i] = t;
        }
        LASTK = NT++; return e;
    }
#if PATH < 2
    e->P = NULL; e->rs = NULL; LASTK = NT++; return e;   /* int8 on paths 0/1: the caller uses mv_u8_ref */
#endif
    e->P = (int8_t*)amalloc((size_t)e->Rp * e->K4 * 4); e->rs = (int32_t*)amalloc(sizeof(int32_t) * (size_t)e->Rp);
    if (!e->P || !e->rs) { free(e->P); free(e->rs); return NULL; }
    for (int i = 0; i < R; i++) {
        size_t g = i / G, rr = i % G, rb = rr / NB, r = rr % NB; int32_t t = 0;
        for (int j = 0; j < C; j++) { int8_t w = W[(long)i * ldw + j]; t += w;
            e->P[(((g * e->K4 + (size_t)(j >> 2)) * RB + rb) * NB + r) * 4 + (j & 3)] = w; }
        e->rs[i] = t;
    }
    LASTK = NT++; return e;
}

static uint8_t XQ[MAXC] __attribute__((aligned(64)));
static int32_t SS[MAXC] __attribute__((aligned(64)));

static float quant(const float* x, int C, int Cp) {   /* identical arithmetic to mv_u8 */
    float m = 1e-12f; for (int j = 0; j < C; j++) { float a = fabsf(x[j]); if (a > m) m = a; }
    float sx = m / 127.f, inv = 1.f / sx;
#if SIGNED_ACT
    for (int j = 0; j < C; j++) XQ[j] = (uint8_t)(int8_t)lrintf(x[j] * inv);
    for (int j = C; j < Cp; j++) XQ[j] = 0;
#elif PATH == 3
    /* VECQ: same rounding as lrintf (round to nearest even), 16 at a time; values 1..255 -> exact u8 */
    int j = 0; const __m512 vinv = _mm512_set1_ps(inv); const __m512i off = _mm512_set1_epi32(128);
    for (; j + 16 <= C; j += 16) _mm_storeu_si128((__m128i*)(XQ + j), _mm512_cvtepi32_epi8(_mm512_add_epi32(_mm512_cvtps_epi32(_mm512_mul_ps(_mm512_loadu_ps(x + j), vinv)), off)));
    for (; j < C; j++) XQ[j] = (uint8_t)(lrintf(x[j] * inv) + 128);
    for (j = C; j < Cp; j++) XQ[j] = 128;
#else
    for (int j = 0; j < C; j++) XQ[j] = (uint8_t)(lrintf(x[j] * inv) + 128);
    for (int j = C; j < Cp; j++) XQ[j] = 128;          /* padded weights are 0, so the value is irrelevant */
#endif
    return sx;
}

static inline int32_t ld4(const uint8_t* p) { int32_t v; memcpy(&v, p, 4); return v; }

#if PATH == 3
static void core(const PK* k, const uint8_t* q, int32_t* S) {
    const int K4 = k->K4; const size_t st = (size_t)G * 4;   /* 256 bytes per k4 */
    for (int g = 0; g < k->Rp / G; g++) {
        const int8_t* p = k->P + (size_t)g * K4 * st;
        __m512i a0 = _mm512_setzero_si512(), a1 = a0, a2 = a0, a3 = a0, c0 = a0, c1 = a0, c2 = a0, c3 = a0;
        int j = 0;
        for (; j + 2 <= K4; j += 2, p += 2 * st) {           /* 8 independent accumulators hide the dpbusd latency */
            __m512i x0 = _mm512_set1_epi32(ld4(q + 4 * j)), x1 = _mm512_set1_epi32(ld4(q + 4 * j + 4));
            a0 = _mm512_dpbusd_epi32(a0, x0, _mm512_load_si512((const void*)(p)));
            a1 = _mm512_dpbusd_epi32(a1, x0, _mm512_load_si512((const void*)(p + 64)));
            a2 = _mm512_dpbusd_epi32(a2, x0, _mm512_load_si512((const void*)(p + 128)));
            a3 = _mm512_dpbusd_epi32(a3, x0, _mm512_load_si512((const void*)(p + 192)));
            c0 = _mm512_dpbusd_epi32(c0, x1, _mm512_load_si512((const void*)(p + 256)));
            c1 = _mm512_dpbusd_epi32(c1, x1, _mm512_load_si512((const void*)(p + 320)));
            c2 = _mm512_dpbusd_epi32(c2, x1, _mm512_load_si512((const void*)(p + 384)));
            c3 = _mm512_dpbusd_epi32(c3, x1, _mm512_load_si512((const void*)(p + 448)));
        }
        if (j < K4) { __m512i x0 = _mm512_set1_epi32(ld4(q + 4 * j));
            a0 = _mm512_dpbusd_epi32(a0, x0, _mm512_load_si512((const void*)(p)));
            a1 = _mm512_dpbusd_epi32(a1, x0, _mm512_load_si512((const void*)(p + 64)));
            a2 = _mm512_dpbusd_epi32(a2, x0, _mm512_load_si512((const void*)(p + 128)));
            a3 = _mm512_dpbusd_epi32(a3, x0, _mm512_load_si512((const void*)(p + 192))); }
        int32_t* s = S + (size_t)g * G;
        _mm512_store_si512((void*)(s), _mm512_add_epi32(a0, c0));
        _mm512_store_si512((void*)(s + 16), _mm512_add_epi32(a1, c1));
        _mm512_store_si512((void*)(s + 32), _mm512_add_epi32(a2, c2));
        _mm512_store_si512((void*)(s + 48), _mm512_add_epi32(a3, c3));
    }
}
#elif PATH == 2 || PATH == 1
#if PATH == 2
#define DOT(acc, xb, w) _mm256_dpbusd_avx_epi32((acc), (xb), (w))
#else
static inline __m256i dot_sign(__m256i acc, __m256i xb, __m256i w) {   /* |w| (u8) x sign(q, w) (s8): exact */
    __m256i p = _mm256_maddubs_epi16(_mm256_abs_epi8(w), _mm256_sign_epi8(xb, w));
    return _mm256_add_epi32(acc, _mm256_madd_epi16(p, _mm256_set1_epi16(1)));
}
#define DOT(acc, xb, w) dot_sign((acc), (xb), (w))
#endif
static void core(const PK* k, const uint8_t* q, int32_t* S) {
    const int K4 = k->K4; const size_t st = (size_t)G * 4;   /* 128 bytes per k4 */
    for (int g = 0; g < k->Rp / G; g++) {
        const int8_t* p = k->P + (size_t)g * K4 * st;
        __m256i a0 = _mm256_setzero_si256(), a1 = a0, a2 = a0, a3 = a0, c0 = a0, c1 = a0, c2 = a0, c3 = a0;
        int j = 0;
        for (; j + 2 <= K4; j += 2, p += 2 * st) {
            __m256i x0 = _mm256_set1_epi32(ld4(q + 4 * j)), x1 = _mm256_set1_epi32(ld4(q + 4 * j + 4));
            a0 = DOT(a0, x0, _mm256_load_si256((const __m256i*)(p)));
            a1 = DOT(a1, x0, _mm256_load_si256((const __m256i*)(p + 32)));
            a2 = DOT(a2, x0, _mm256_load_si256((const __m256i*)(p + 64)));
            a3 = DOT(a3, x0, _mm256_load_si256((const __m256i*)(p + 96)));
            c0 = DOT(c0, x1, _mm256_load_si256((const __m256i*)(p + 128)));
            c1 = DOT(c1, x1, _mm256_load_si256((const __m256i*)(p + 160)));
            c2 = DOT(c2, x1, _mm256_load_si256((const __m256i*)(p + 192)));
            c3 = DOT(c3, x1, _mm256_load_si256((const __m256i*)(p + 224)));
        }
        if (j < K4) { __m256i x0 = _mm256_set1_epi32(ld4(q + 4 * j));
            a0 = DOT(a0, x0, _mm256_load_si256((const __m256i*)(p)));
            a1 = DOT(a1, x0, _mm256_load_si256((const __m256i*)(p + 32)));
            a2 = DOT(a2, x0, _mm256_load_si256((const __m256i*)(p + 64)));
            a3 = DOT(a3, x0, _mm256_load_si256((const __m256i*)(p + 96))); }
        int32_t* s = S + (size_t)g * G;
        _mm256_store_si256((__m256i*)(s), _mm256_add_epi32(a0, c0));
        _mm256_store_si256((__m256i*)(s + 8), _mm256_add_epi32(a1, c1));
        _mm256_store_si256((__m256i*)(s + 16), _mm256_add_epi32(a2, c2));
        _mm256_store_si256((__m256i*)(s + 24), _mm256_add_epi32(a3, c3));
    }
}
#else
static void core(const PK* k, const uint8_t* q, int32_t* S) {
    const int K4 = k->K4;
    for (int i = 0; i < k->Rp; i++) S[i] = 0;
    for (int g = 0; g < k->Rp / G; g++) for (int j = 0; j < K4; j++) for (int rb = 0; rb < RB; rb++) for (int r = 0; r < NB; r++) {
        const int8_t* w = k->P + ((((size_t)g * K4 + j) * RB + rb) * NB + r) * 4; int32_t s = 0;
        for (int t = 0; t < 4; t++) s += (int32_t)w[t] * (int32_t)(int8_t)q[4 * j + t];
        S[(size_t)g * G + rb * NB + r] += s;
    }
}
#endif

/* ------------------------------------------------------------------ Q4K nibble kernels: S'[i] = sum_j (w_ij + 8) q_j */
/* layout: [group][k4][pair < RB/2][r < NB][t < 4] bytes; low nibble = row block 2*pair, high nibble = 2*pair + 1 */
#if PATH == 3
static void core4(const PK* k, const uint8_t* q, int32_t* S) {
    const int K4 = k->K4; const size_t st = (size_t)G * 2;   /* 128 bytes per k4 */
    const __m512i m = _mm512_set1_epi8(0x0F);
    for (int g = 0; g < k->Rp / G; g++) {
        const int8_t* p = k->P + (size_t)g * K4 * st;
        __m512i a0 = _mm512_setzero_si512(), a1 = a0, a2 = a0, a3 = a0, c0 = a0, c1 = a0, c2 = a0, c3 = a0;
        int j = 0;
        for (; j + 2 <= K4; j += 2, p += 2 * st) {
            __m512i x0 = _mm512_set1_epi32(ld4(q + 4 * j)), x1 = _mm512_set1_epi32(ld4(q + 4 * j + 4));
            __m512i v0 = _mm512_load_si512((const void*)(p)), v1 = _mm512_load_si512((const void*)(p + 64));
            __m512i v2 = _mm512_load_si512((const void*)(p + 128)), v3 = _mm512_load_si512((const void*)(p + 192));
            a0 = _mm512_dpbusd_epi32(a0, x0, _mm512_and_si512(v0, m)); a1 = _mm512_dpbusd_epi32(a1, x0, _mm512_and_si512(_mm512_srli_epi16(v0, 4), m));
            a2 = _mm512_dpbusd_epi32(a2, x0, _mm512_and_si512(v1, m)); a3 = _mm512_dpbusd_epi32(a3, x0, _mm512_and_si512(_mm512_srli_epi16(v1, 4), m));
            c0 = _mm512_dpbusd_epi32(c0, x1, _mm512_and_si512(v2, m)); c1 = _mm512_dpbusd_epi32(c1, x1, _mm512_and_si512(_mm512_srli_epi16(v2, 4), m));
            c2 = _mm512_dpbusd_epi32(c2, x1, _mm512_and_si512(v3, m)); c3 = _mm512_dpbusd_epi32(c3, x1, _mm512_and_si512(_mm512_srli_epi16(v3, 4), m));
        }
        if (j < K4) { __m512i x0 = _mm512_set1_epi32(ld4(q + 4 * j));
            __m512i v0 = _mm512_load_si512((const void*)(p)), v1 = _mm512_load_si512((const void*)(p + 64));
            a0 = _mm512_dpbusd_epi32(a0, x0, _mm512_and_si512(v0, m)); a1 = _mm512_dpbusd_epi32(a1, x0, _mm512_and_si512(_mm512_srli_epi16(v0, 4), m));
            a2 = _mm512_dpbusd_epi32(a2, x0, _mm512_and_si512(v1, m)); a3 = _mm512_dpbusd_epi32(a3, x0, _mm512_and_si512(_mm512_srli_epi16(v1, 4), m)); }
        int32_t* s = S + (size_t)g * G;
        _mm512_store_si512((void*)(s), _mm512_add_epi32(a0, c0));
        _mm512_store_si512((void*)(s + 16), _mm512_add_epi32(a1, c1));
        _mm512_store_si512((void*)(s + 32), _mm512_add_epi32(a2, c2));
        _mm512_store_si512((void*)(s + 48), _mm512_add_epi32(a3, c3));
    }
}
#elif PATH == 2 || PATH == 1
#if PATH == 2
#define DOT4(acc, xb, w) _mm256_dpbusd_avx_epi32((acc), (xb), (w))
#else
#define DOT4(acc, xb, w) _mm256_add_epi32((acc), _mm256_madd_epi16(_mm256_maddubs_epi16((w), (xb)), _mm256_set1_epi16(1)))
#endif
static void core4(const PK* k, const uint8_t* q, int32_t* S) {
    const int K4 = k->K4; const size_t st = (size_t)G * 2;   /* 64 bytes per k4 */
    const __m256i m = _mm256_set1_epi8(0x0F);
    for (int g = 0; g < k->Rp / G; g++) {
        const int8_t* p = k->P + (size_t)g * K4 * st;
        __m256i a0 = _mm256_setzero_si256(), a1 = a0, a2 = a0, a3 = a0, c0 = a0, c1 = a0, c2 = a0, c3 = a0;
        int j = 0;
        for (; j + 2 <= K4; j += 2, p += 2 * st) {
            __m256i x0 = _mm256_set1_epi32(ld4(q + 4 * j)), x1 = _mm256_set1_epi32(ld4(q + 4 * j + 4));
            __m256i v0 = _mm256_load_si256((const __m256i*)(p)), v1 = _mm256_load_si256((const __m256i*)(p + 32));
            __m256i v2 = _mm256_load_si256((const __m256i*)(p + 64)), v3 = _mm256_load_si256((const __m256i*)(p + 96));
            a0 = DOT4(a0, x0, _mm256_and_si256(v0, m)); a1 = DOT4(a1, x0, _mm256_and_si256(_mm256_srli_epi16(v0, 4), m));
            a2 = DOT4(a2, x0, _mm256_and_si256(v1, m)); a3 = DOT4(a3, x0, _mm256_and_si256(_mm256_srli_epi16(v1, 4), m));
            c0 = DOT4(c0, x1, _mm256_and_si256(v2, m)); c1 = DOT4(c1, x1, _mm256_and_si256(_mm256_srli_epi16(v2, 4), m));
            c2 = DOT4(c2, x1, _mm256_and_si256(v3, m)); c3 = DOT4(c3, x1, _mm256_and_si256(_mm256_srli_epi16(v3, 4), m));
        }
        if (j < K4) { __m256i x0 = _mm256_set1_epi32(ld4(q + 4 * j));
            __m256i v0 = _mm256_load_si256((const __m256i*)(p)), v1 = _mm256_load_si256((const __m256i*)(p + 32));
            a0 = DOT4(a0, x0, _mm256_and_si256(v0, m)); a1 = DOT4(a1, x0, _mm256_and_si256(_mm256_srli_epi16(v0, 4), m));
            a2 = DOT4(a2, x0, _mm256_and_si256(v1, m)); a3 = DOT4(a3, x0, _mm256_and_si256(_mm256_srli_epi16(v1, 4), m)); }
        int32_t* s = S + (size_t)g * G;
        _mm256_store_si256((__m256i*)(s), _mm256_add_epi32(a0, c0));
        _mm256_store_si256((__m256i*)(s + 8), _mm256_add_epi32(a1, c1));
        _mm256_store_si256((__m256i*)(s + 16), _mm256_add_epi32(a2, c2));
        _mm256_store_si256((__m256i*)(s + 24), _mm256_add_epi32(a3, c3));
    }
}
#else
static void core4(const PK* k, const uint8_t* q, int32_t* S) {
    const int K4 = k->K4;
    for (int i = 0; i < k->Rp; i++) S[i] = 0;
    for (int g = 0; g < k->Rp / G; g++) for (int j = 0; j < K4; j++) for (int pr = 0; pr < RB / 2; pr++) for (int r = 0; r < NB; r++) {
        const uint8_t* w = (const uint8_t*)k->P + ((((size_t)g * K4 + j) * (RB / 2) + pr) * NB + r) * 4; int32_t s0 = 0, s1 = 0;
        for (int t = 0; t < 4; t++) { int32_t x = (int32_t)(int8_t)q[4 * j + t]; s0 += (int32_t)(w[t] & 15) * x; s1 += (int32_t)(w[t] >> 4) * x; }
        S[(size_t)g * G + (2 * pr) * NB + r] += s0; S[(size_t)g * G + (2 * pr + 1) * NB + r] += s1;
    }
}
#endif
static int32_t qsum(const uint8_t* q, int Cp) {   /* sum of the activations as the kernel reads them (padding included) */
    int32_t t = 0;
    for (int j = 0; j < Cp; j++) t += SIGNED_ACT ? (int32_t)(int8_t)q[j] : (int32_t)q[j];
    return t;
}
static void mvp4(const PK* k, const float* sc, const float* x, const float* b, float* out, int R, int C) {
    const float sx = quant(x, C, 4 * k->K4);
    core4(k, XQ, SS);
    const int32_t c8 = 8 * qsum(XQ, 4 * k->K4); const int32_t* rs = k->rs;
    for (int i = 0; i < R; i++) out[i] = b[i] + sc[i] * (sx * (float)(SS[i] - c8 - (SIGNED_ACT ? 0 : 128 * rs[i])));
}

/* drop-in for mv_u8 */
void mvp(const int8_t* W, long ldw, const float* sc, const float* x, const float* b, float* out, int R, int C) {
    PK* k = (C <= MAXC - 4 && R <= MAXC - G) ? lookup(W, ldw, R, C) : NULL;
    if (!k || (!k->q4 && !k->P)) { mv_u8_ref(W, ldw, sc, x, b, out, R, C); return; }
    if (k->q4) { mvp4(k, sc, x, b, out, R, C); return; }
#if PATH >= 2
    const float sx = quant(x, C, 4 * k->K4);
    core(k, XQ, SS);
#if SIGNED_ACT
    for (int i = 0; i < R; i++) out[i] = b[i] + sc[i] * (sx * (float)SS[i]);
#else
    const int32_t* rs = k->rs;
    for (int i = 0; i < R; i++) out[i] = b[i] + sc[i] * (sx * (float)(SS[i] - 128 * rs[i]));
#endif
#else
    mv_u8_ref(W, ldw, sc, x, b, out, R, C);
#endif
}
void mvp_raw(const int8_t* W, long ldw, const float* x, int32_t* S, int R, int C) {
    PK* k = lookup(W, ldw, R, C);
    if (k->q4) { quant(x, C, 4 * k->K4); core4(k, XQ, SS); const int32_t c8 = 8 * qsum(XQ, 4 * k->K4);
        for (int i = 0; i < R; i++) S[i] = SS[i] - c8 - (SIGNED_ACT ? 0 : 128 * k->rs[i]); return; }
    if (!k->P) { mv_u8_raw(W, ldw, x, S, R, C); return; }
    quant(x, C, 4 * k->K4); core(k, XQ, SS);
    for (int i = 0; i < R; i++) S[i] = SS[i] - (SIGNED_ACT ? 0 : 128 * k->rs[i]);
}

/* ------------------------------------------------------------------ whole minGRU layer stack in one call (proposal 3) */
/* Same math as mingru_step's layer loop (float64 LN / tables, float32 storage). Strides in elements. */
static inline double sig_t(double v, const double* T) {
    double t = (v - (-16.0)) * (2048.0 / 32.0);
    if (t <= 0.0 || t >= 2048.0) return 1.0 / (1.0 + exp(-v));
    int i = (int)t; double f = t - i; return T[i] + f * (T[i + 1] - T[i]);
}
static inline double gelu_t(double v, const double* T) {
    double t = (v - (-6.0)) * (2048.0 / 12.0);
    if (t <= 0.0) return 0.0 * v;
    if (t >= 2048.0) return v;
    int i = (int)t; double f = t - i; double e = T[i] + f * (T[i + 1] - T[i]); return 0.5 * v * (1.0 + e);
}
#ifndef NO_VECACT
#define VECACT 1   /* VECACT: float32 gate / GELU with vectorised expf (gcc -ffast-math + libmvec, link -lm) */
#endif
static inline float sigf(float v) { return 1.f / (1.f + expf(-v)); }
static inline float geluf(float v) {   /* 0.5 v (1 + erf(v / sqrt 2)); erf: Abramowitz-Stegun 7.1.26, |error| <= 1.5e-7 */
    const float x = fabsf(v) * 0.70710678f, t = 1.f / (1.f + 0.3275911f * x);
    const float y = 1.f - (((((1.061405429f * t - 1.453152027f) * t) + 1.421413741f) * t - 0.284496736f) * t + 0.254829592f) * t * expf(-x * x);
    return 0.5f * v * (1.f + (v >= 0.f ? y : -y));
}
static void ln(const float* u, const float* w, const float* b, float* o, int H) {
    double m = 0.0; for (int i = 0; i < H; i++) m += u[i];
    m /= H; double v = 0.0;
    for (int i = 0; i < H; i++) { double d = u[i] - m; v += d * d; }
    double inv = 1.0 / sqrt(v / H + 1e-5);
    for (int i = 0; i < H; i++) o[i] = (float)((u[i] - m) * inv * w[i] + b[i]);
}
void head_rows(int R, int H, int W, const float* Hw, long ldh, const float* F, long ldf, const float* Hb,
               const float* u, const float* g, float* out, int fold) {   /* HEADC: out[r] = Hb[r] + Hw[r] . u (+ F[r] . g) */
    for (int r = 0; r < R; r++) {
        const float* hw = Hw + (long)r * ldh; float s = 0.f; for (int j = 0; j < H; j++) s += hw[j] * u[j];
        if (fold & 1) { const float* f = F + (long)r * ldf; float t = 0.f; for (int k = 0; k < W; k++) t += f[k] * g[k]; s += t; }
        out[r] = Hb[r] + s;
    }
}
#define MVSEL mvp   /* Q4K: every path; paths 0/1 send int8 matrices on to mv_u8_ref inside mvp */
void mvsel(const int8_t* W, long ldw, const float* sc, const float* x, const float* b, float* out, int R, int C) { MVSEL(W, ldw, sc, x, b, out, R, C); }
void mg_layers(int L, int H, int MW,
               const int8_t* Gw, long Gl, long Gr, const float* Gs, const float* Gb, long Gv,
               const int8_t* M1w, long M1l, long M1r, const float* M1s, const float* M1b, long M1v,
               const int8_t* M2w, long M2l, long M2r, const float* M2s, const float* M2b, long M2v,
               const float* l1w, const float* l1b, const float* l2w, const float* l2b, long lv,
               float* h, long hl, float* u, const double* SIG, const double* ERF, int fold, float* gout) {
    float t1[MAXC / 4], g2[MAXC / 4], t3[MAXC / 4];
    const int sgn = fold & 2; fold &= 1;   /* BIGSWARM signed candidate tanh(c) = 2 sigmoid(2c) - 1 */
    for (int l = 0; l < L; l++) {
        float* hp = h + l * hl;
        ln(u, l1w + l * lv, l1b + l * lv, t1, H);
        MVSEL(Gw + l * Gl, Gr, Gs + l * Gv, t1, Gb + l * Gv, g2, 2 * H, H);
#ifdef VECACT
        for (int i = 0; i < H; i++) {
            const float z = sigf(g2[i]), c = g2[H + i], gc = sgn ? 2.f * sigf(2.f * c) - 1.f : (c >= 0.f ? c + 0.5f : sigf(c));
            hp[i] = (1.f - z) * hp[i] + z * gc; u[i] += hp[i];
        }
#else
        for (int i = 0; i < H; i++) {
            double z = sig_t(g2[i], SIG), c = g2[H + i];
            double gc = sgn ? 2.0 * sig_t(2.0 * c, SIG) - 1.0 : (c >= 0.0 ? c + 0.5 : sig_t(c, SIG));
            hp[i] = (float)((1.0 - z) * hp[i] + z * gc); u[i] += hp[i];
        }
#endif
        ln(u, l2w + l * lv, l2b + l * lv, t1, H);
        MVSEL(M1w + l * M1l, M1r, M1s + l * M1v, t1, M1b + l * M1v, g2, MW, H);
#ifdef VECACT
        for (int i = 0; i < MW; i++) g2[i] = geluf(g2[i]);
#else
        for (int i = 0; i < MW; i++) g2[i] = (float)gelu_t(g2[i], ERF);
#endif
        if (fold && l == L - 1) { memcpy(gout, g2, sizeof(float) * MW); break; }   /* HEADFOLD: head applies F = Hw M2 */
        MVSEL(M2w + l * M2l, M2r, M2s + l * M2v, g2, M2b + l * M2v, t3, H, MW);
        for (int i = 0; i < H; i++) u[i] += t3[i];
    }
}


"""


_SELFTEST = r"""
import ctypes, sys, numpy as np
L = ctypes.CDLL(sys.argv[1]); r = np.random.default_rng(0); P = ctypes.c_void_p
for f in (L.mvsel, L.mv_u8_ref): f.restype = None; f.argtypes = [P, ctypes.c_long, P, P, P, P, ctypes.c_int, ctypes.c_int]
for f in (L.mvp_raw, L.mv_u8_raw): f.restype = None; f.argtypes = [P, ctypes.c_long, P, P, ctypes.c_int, ctypes.c_int]
for R, C, ld in ((384, 192, 192), (768, 384, 384), (384, 768, 768), (70, 186, 190)):   # Q4K: int4 sums must be EXACT
    W = r.integers(-7, 8, (R, ld)).astype(np.int8); x = r.normal(0, 1, C).astype(np.float32)
    s1 = np.zeros(R, np.int32); s2 = np.zeros(R, np.int32)
    L.mvp_raw(W.ctypes.data, ld, x.ctypes.data, s1.ctypes.data, R, C); L.mv_u8_raw(W.ctypes.data, ld, x.ctypes.data, s2.ctypes.data, R, C)
    if not np.array_equal(s1, s2): print("FAIL raw", R, C, int(np.abs(s1 - s2).max())); sys.exit(4)
for R, C, ld, lo in ((384, 192, 192, -128), (256, 128, 192, -128), (192, 384, 384, -128), (70, 186, 190, -128),
                     (384, 192, 192, -7), (768, 384, 384, -7), (384, 768, 768, -7), (70, 186, 190, -7), (40, 30, 30, -7)):
    W = r.integers(lo, 8 if lo == -7 else 128, (R, ld)).astype(np.int8); sc = r.random(R).astype(np.float32); b = r.normal(0, 1, R).astype(np.float32)
    for x in (r.normal(0, 1, C).astype(np.float32), np.zeros(C, np.float32), -np.abs(r.normal(0, 3, C)).astype(np.float32)):
        o1 = np.zeros(R, np.float32); o2 = np.zeros(R, np.float32); a = [W.ctypes.data, ld, sc.ctypes.data, x.ctypes.data, b.ctypes.data]
        L.mvsel(*a, o1.ctypes.data, R, C); L.mv_u8_ref(*a, o2.ctypes.data, R, C)
        if not np.allclose(o1, o2, rtol=1e-5, atol=1e-5 * float(np.abs(o2).max() + 1)): print("FAIL", R, C, lo); sys.exit(3)   # gcc 12 fast-math: ~1 ulp
print("OK", L.mvp_path())
"""


def _build_c():
    """VNNI (2026-10-26): build the kernels for THIS CPU, then a self-test in a separate process (a VM that claims an ISA it
    cannot run, or a kernel that disagrees with the shipped arithmetic, is rejected) -> {'mv', 'layers', 'path'} or None."""
    if os.environ.get("WNN_NO_C") == "1": return None
    import sys as _sys
    h = hashlib.md5((_C_SRC + os.environ.get("WNN_FORCE_PATH", "")).encode()).hexdigest()[:10]
    for d in (tempfile.gettempdir(), str(HERE), "/app/.cache"):
        try:
            so = os.path.join(d, f"wnn_mv_{h}_{os.getpid()}.so"); src = so[:-3] + ".c"
            with open(src, "w") as fh: fh.write(_C_SRC)
            subprocess.run(["gcc", "-O3", "-march=native", "-ffast-math", "-shared", "-fPIC"] + (["-DFORCE_PATH=" + os.environ["WNN_FORCE_PATH"]] if os.environ.get("WNN_FORCE_PATH") else []) + (["-DNO_VECACT"] if os.environ.get("WNN_TABLE_ACT") == "1" else [])
                           + [src, "-o", so, "-lm"], check=True, capture_output=True, timeout=120)
            st = subprocess.run([_sys.executable, "-c", _SELFTEST, so], capture_output=True, text=True, timeout=120)
            if st.returncode != 0 or not st.stdout.startswith("OK"): continue
            lib = ctypes.CDLL(so); P = ctypes.c_void_p; Lg, I = ctypes.c_long, ctypes.c_int
            f = lib.mvsel; f.restype = None; f.argtypes = [P, Lg, P, P, P, P, I, I]
            g = lib.mg_layers; g.restype = None
            g.argtypes = [I, I, I, P, Lg, Lg, P, P, Lg, P, Lg, Lg, P, P, Lg, P, Lg, Lg, P, P, Lg, P, P, P, P, Lg, P, Lg, P, P, P, I, P]
            hd = lib.head_rows; hd.restype = None; hd.argtypes = [I, I, I, P, Lg, P, Lg, P, P, P, P, I]
            return {"mv": f, "layers": g, "head": hd, "path": int(st.stdout.split()[1])}
        except Exception:
            continue
    return None


_CLIB = _build_c(); USE_C = _CLIB is not None; _CACHE = not USE_C   # kernels that call C hold its address: never cache them
_CMV = _CLIB["mv"] if USE_C else None; _CMG = _CLIB["layers"] if USE_C else None; _CHD = _CLIB["head"] if USE_C else None; C_PATH = _CLIB["path"] if USE_C else -1
SENT = np.float32(-5.199337)

# SPEED1: erf (inside GELU) and exp (inside the gate sigmoids) were ~half of a minGRU member's per-row time. Both are read
# from fine tables with linear interpolation (max error ~1e-6, far below the int8 weight rounding).
_ERF_LO, _ERF_HI, _ERF_N = -6.0, 6.0, 2049   # CACHE: 16 KB table (was 16385 entries, 131 KB)
_ERF_T = np.array([math.erf(v * 0.7071067811865476) for v in np.linspace(_ERF_LO, _ERF_HI, _ERF_N)])
_ERF_INV = (_ERF_N - 1) / (_ERF_HI - _ERF_LO)
_SIG_LO, _SIG_HI, _SIG_N = -16.0, 16.0, 2049
_SIG_T = np.array([1.0 / (1.0 + math.exp(-v)) for v in np.linspace(_SIG_LO, _SIG_HI, _SIG_N)])
_SIG_INV = (_SIG_N - 1) / (_SIG_HI - _SIG_LO)


@njit(fastmath=True, cache=True, inline="always")
def _gelu_t(v):
    t = (v - _ERF_LO) * _ERF_INV
    if t <= 0.0: return 0.0 * v
    if t >= _ERF_N - 1: return v
    i = int(t); f = t - i; e = _ERF_T[i] + f * (_ERF_T[i + 1] - _ERF_T[i])
    return 0.5 * v * (1.0 + e)


@njit(fastmath=True, cache=True, inline="always")
def _sig_t(v):
    t = (v - _SIG_LO) * _SIG_INV
    if t <= 0.0: return 1.0 / (1.0 + math.exp(-v))
    if t >= _SIG_N - 1: return 1.0 / (1.0 + math.exp(-v))
    i = int(t); f = t - i
    return _SIG_T[i] + f * (_SIG_T[i + 1] - _SIG_T[i])


# ============================================================== GRU (PyTorch gate order r, z, n)
@njit(fastmath=True, cache=True)
def _matvec(W, x, b, out):
    for i in range(W.shape[0]):
        s = b[i]
        for j in range(W.shape[1]):
            s += W[i, j] * x[j]
        out[i] = s


@njit(fastmath=True, cache=True)
def _gru_update(gx, h, Whh, bhh, tmp, H):
    _matvec(Whh, h, bhh, tmp)
    for i in range(H):
        r = 1.0 / (1.0 + math.exp(-(gx[i] + tmp[i])))
        z = 1.0 / (1.0 + math.exp(-(gx[H + i] + tmp[H + i])))
        n = math.tanh(gx[2 * H + i] + r * tmp[2 * H + i])
        h[i] = (1.0 - z) * n + z * h[i]


@njit(fastmath=True, cache=True)
def gru_step(inp, W0, b0, R0, c0, W1, b1, R1, c1, Wh, bh, h0, h1, gx, tmp, out):
    H = h0.shape[0]
    _matvec(W0, inp, b0, gx); _gru_update(gx, h0, R0, c0, tmp, H)
    _matvec(W1, h0, b1, gx); _gru_update(gx, h1, R1, c1, tmp, H)
    z0 = bh[0]; z1 = bh[1]
    for j in range(H):
        z0 += Wh[0, j] * h1[j]; z1 += Wh[1, j] * h1[j]
    out[0] = z0 - z1; out[1] = -z0 - z1


@njit(cache=True)
def build_raw_d1(x, prev, first, inp, sc):
    for c in range(112):
        inp[c] = x[c]
        inp[112 + c] = 0.0 if first else x[c] - prev[c]
        prev[c] = x[c]
    for k in range(sc.shape[0]):
        inp[224 + k] = 1.0 if abs(x[sc[k]] - SENT) < 1e-3 else 0.0


# ============================================================== 'reg' input set (streaming version of features.compute("reg"))
@njit(cache=True)
def reg_row(x, first, out, xc, prev, rates, m500, m2000, held, sent_cols, zero_cols, med, lo, hi):
    """One row of the 'reg' inputs into out (299): [xc 112, d1 112, missing flags, zero flags, rates 4, vol - EMA500 22,
    vol - EMA2000 22, vol - vol at last mid event 22]. float64 state, exactly as features.compute (EMA m = (1-a) m + a v,
    started at 0 for rates and at the first row for volumes)."""
    for c in range(112): xc[c] = np.float64(x[c])
    ns = sent_cols.shape[0]; nz = zero_cols.shape[0]
    for i in range(ns):
        c = sent_cols[i]; miss = abs(x[c] - np.float32(-5.199337)) < 1e-3
        if miss: xc[c] = med[c]
        out[224 + i] = 1.0 if miss else 0.0
    for i in range(nz):
        out[224 + ns + i] = 1.0 if x[zero_cols[i]] == 0 else 0.0
    for c in range(112):
        v = xc[c]
        if v < lo[c]: v = lo[c]
        if v > hi[c]: v = hi[c]
        xc[c] = np.float64(np.float32(v))
    if first:
        for c in range(112): prev[c] = xc[c]
        for k in range(4): rates[k] = 0.0
        for j in range(22):
            m500[j] = xc[22 + j]; m2000[j] = xc[22 + j]; held[j] = xc[22 + j]
    U = False; Eb = False; Ea = False; TR = False; I1 = False
    for c in range(112):
        d = np.float32(xc[c]) - np.float32(prev[c])
        out[c] = xc[c]; out[112 + c] = d
        if d != 0.0:
            if c < 22: U = True
            if c < 11: Eb = True
            if 11 <= c < 22: Ea = True
            if 48 <= c < 52: TR = True
            if 52 <= c < 74: I1 = True
    E = Eb and Ea
    o = 224 + ns + nz
    fl = (1.0 if U else 0.0, 1.0 if U else 0.0, 1.0 if TR else 0.0, 1.0 if I1 else 0.0)
    al = (1e-3, 5e-3, 1e-3, 1e-3)
    for k in range(4):
        rates[k] = (1.0 - al[k]) * rates[k] + al[k] * fl[k]; out[o + k] = rates[k]
    o += 4
    e = 1.0 if E else 0.0
    for j in range(22):
        v = xc[22 + j]
        m500[j] = (1.0 - 1.0 / 500.0) * m500[j] + v / 500.0; m2000[j] = (1.0 - 1.0 / 2000.0) * m2000[j] + v / 2000.0
        held[j] = (1.0 - e) * held[j] + e * v
        out[o + j] = v - m500[j]; out[o + 22 + j] = v - m2000[j]; out[o + 44 + j] = v - held[j]
    for c in range(112): prev[c] = xc[c]


# ============================================================== W1D features (long640 + xD z-scores)
@njit(fastmath=False, cache=True)
def w1d_feat_row(x, first, f, xc, prev, m3, since, act, femas, gap_e, mq, sent_cols, zero_cols, med, lo, hi, groups):
    for c in range(112): xc[c] = x[c]
    for i in range(sent_cols.shape[0]):
        c = sent_cols[i]; miss = abs(x[c] - np.float32(-5.199337)) < 1e-3
        if miss: xc[c] = med[c]
        f[224 + i] = 1.0 if miss else 0.0
    for i in range(zero_cols.shape[0]):
        f[224 + sent_cols.shape[0] + i] = 1.0 if x[zero_cols[i]] == 0 else 0.0
    for c in range(112):
        v = xc[c]
        if v < lo[c]: v = lo[c]
        if v > hi[c]: v = hi[c]
        xc[c] = v
    if first:
        for c in range(112):
            prev[c] = xc[c]
            for s in range(3): m3[s, c] = xc[c]
            v = np.float64(xc[c])
            mq[0, c] = v; mq[1, c] = v * v; mq[2, c] = v; mq[3, c] = v * v
        for g in range(13):
            since[g] = 0.0; act[0, g] = 0.0; act[1, g] = 0.0
        for j in range(femas.shape[0]): femas[j] = 0.0
        g0 = 0.0
        for c in range(22): g0 += xc[c] - xc[52 + c]
        gap_e[0] = g0
    base = 229
    for c in range(112):
        f[c] = xc[c]; f[112 + c] = xc[c] - prev[c]
    for s in range(3):
        a = 1.0 / (10.0 if s == 0 else (100.0 if s == 1 else 1000.0))
        for c in range(112):
            m = (1.0 - a) * m3[s, c] + a * xc[c]; m3[s, c] = m
            f[base + s * 112 + c] = np.float32(xc[c] - m)
    o = base + 336
    for g in range(13):
        chg = False
        for c in range(groups[g, 0], groups[g, 1]):
            if xc[c] - prev[c] != 0.0: chg = True
        since[g] = 0.0 if chg else since[g] + 1.0
        f[o + g] = 1.0 if chg else 0.0
        f[o + 13 + g] = np.float32(math.log1p(since[g]))
        cv = 1.0 if chg else 0.0
        act[0, g] = 0.99 * act[0, g] + 0.01 * cv
        act[1, g] = 0.999 * act[1, g] + 0.001 * cv
        f[o + 26 + g] = np.float32(act[0, g]); f[o + 39 + g] = np.float32(act[1, g])
    o += 52
    k = 0
    for inst in range(2):
        b = 0 if inst == 0 else 52
        dp = 44 if inst == 0 else 96; dv = 48 if inst == 0 else 100
        mv = 0.0
        for c in range(b, b + 22):
            d = xc[c] - prev[c]
            mv += 1.0 if d > 0 else (-1.0 if d < 0 else 0.0)
        ofi = 0.0
        for l in range(11):
            bp, pbp = xc[b + l], prev[b + l]; ap, pap = xc[b + 11 + l], prev[b + 11 + l]
            bv, pbv = xc[b + 22 + l], prev[b + 22 + l]; av, pav = xc[b + 33 + l], prev[b + 33 + l]
            eb = (bv if bp >= pbp else 0.0) - (pbv if bp <= pbp else 0.0)
            ea = (av if ap <= pap else 0.0) - (pav if ap >= pap else 0.0)
            ofi += eb - ea
        tf = 0.0
        for j in range(4):
            d = xc[dp + j] - prev[dp + j]
            sg = 1.0 if d > 0 else (-1.0 if d < 0 else 0.0)
            tf += sg * xc[dv + j]
        for sig in range(3):
            v = mv if sig == 0 else (ofi if sig == 1 else tf)
            f[o] = np.float32(v); o += 1
            nsp = 3 if sig < 2 else 2
            for s in range(nsp):
                a = 1.0 / (10.0 if s == 0 else (100.0 if s == 1 else 1000.0))
                e = (1.0 - a) * femas[k] + a * v; femas[k] = e; k += 1
                f[o] = np.float32(e); o += 1
    gp = 0.0
    for c in range(22): gp += xc[c] - xc[52 + c]
    ge = 0.999 * gap_e[0] + 0.001 * gp; gap_e[0] = ge
    f[o] = np.float32(gp - ge); o += 1
    # xD: z-scores over 100 and 1000 rows (EMA mean / EMA second moment, float64), clamped +-8
    for s in range(2):
        a = 1.0 / (100.0 if s == 0 else 1000.0)
        for c in range(112):
            v = np.float64(xc[c])
            m = (1.0 - a) * mq[2 * s, c] + a * v; q = (1.0 - a) * mq[2 * s + 1, c] + a * v * v
            mq[2 * s, c] = m; mq[2 * s + 1, c] = q
            var = q - m * m
            if var < 1e-6: var = 1e-6
            z = (v - m) / math.sqrt(var)
            if z < -8.0: z = -8.0
            if z > 8.0: z = 8.0
            f[o] = np.float32(z); o += 1
    for c in range(112): prev[c] = xc[c]


@njit(fastmath=True, cache=True)
def mlp_row(f, mu, inv_sd, fn, W0, b0, W1, b1, W2, b2, W3, b3, h0, h1, h2, out):
    for j in range(f.shape[0]):
        v = (f[j] - mu[j]) * inv_sd[j]
        fn[j] = -10.0 if v < -10.0 else (10.0 if v > 10.0 else v)
    for i in range(W0.shape[0]):
        s = b0[i]
        for j in range(W0.shape[1]):
            s += W0[i, j] * fn[j]
        h0[i] = 0.5 * s * (1.0 + math.erf(s * 0.7071067811865476))
    for i in range(W1.shape[0]):
        s = b1[i]
        for j in range(W1.shape[1]): s += W1[i, j] * h0[j]
        h1[i] = 0.5 * s * (1.0 + math.erf(s * 0.7071067811865476))
    for i in range(W2.shape[0]):
        s = b2[i]
        for j in range(W2.shape[1]): s += W2[i, j] * h1[j]
        h2[i] = 0.5 * s * (1.0 + math.erf(s * 0.7071067811865476))
    z0 = b3[0]; z1 = b3[1]
    for j in range(W3.shape[1]):
        z0 += W3[0, j] * h2[j]; z1 += W3[1, j] * h2[j]
    out[0] = z0 - z1; out[1] = -z0 - z1


# ============================================================== evt2 (streaming version of explore/evt2.py)
# sf (float64 scalars): 0 rE10, 1 rE100, 2 snap_b, 3 snap_a, 4 sumgap, 5 vel, 6 vel_e, 7 mmax, 8 mmin, 9 absdm,
#                       10 ph_p, 11 ph_n, 12-14 e5k, 15-17 cm
# si (int64 scalars):   0 lastE, 1 nb, 2 na, 3 ntr, 4 ni1, 5 nU, 6 lastU, 7 tmax, 8 tmin
@njit(cache=True)
def evt2_step(x, xp, t, out, sf, si, ring_m, ring_t, gaps, cnt, last, osum, on, slot_hist, m_hist, d0, d1, d2,
              mub, vb, sdb, mua, va, sda, KS, SLOW):
    sb = 0.0; sa = 0.0
    for j in range(11):
        sb += (np.float64(x[j]) - mub[j]) * vb[j]; sa += (np.float64(x[11 + j]) - mua[j]) * va[j]
    mt = sb / sdb + sa / sda; m_hist[t] = mt
    bch = False; ach = False; trch = False; i1ch = False
    if t > 0:
        for j in range(11):
            if x[j] != xp[j]: bch = True
            if x[11 + j] != xp[11 + j]: ach = True
        for j in range(44, 52):
            if x[j] != xp[j]: trch = True
        for j in range(52, 74):
            if x[j] != xp[j]: i1ch = True
    E = bch and ach; U = bch or ach
    bv = 0.0; av = 0.0
    for j in range(11):
        bv += np.float64(x[22 + j]); av += np.float64(x[33 + j])
    if t == 0 or E:
        si[0] = t; si[1] = 0; si[2] = 0; si[3] = 0; si[4] = 0; sf[2] = bv; sf[3] = av
    else:
        if bch and not ach: si[1] += 1
        if ach and not bch: si[2] += 1
        if trch: si[3] += 1
        if i1ch: si[4] += 1
    e = 1.0 if E else 0.0
    sf[0] += 0.1 * (e - sf[0]); sf[1] += 0.01 * (e - sf[1])
    out[0] = np.log1p(t - si[0]); out[1] = sf[0]; out[2] = sf[1]
    out[3] = np.log1p(si[1]); out[4] = np.log1p(si[2]); out[5] = np.log1p(si[3]); out[6] = np.log1p(si[4])
    out[7] = bv - sf[2]; out[8] = av - sf[3]; out[9] = (bv - av) - (sf[2] - sf[3])
    RING = ring_m.shape[0]
    if t == 0 or U:
        nU = si[5]
        if t > 0:
            g = t - si[6]; dm = mt - m_hist[si[6]]
            gaps[(nU - 1) % 8] = g; sf[4] += g
            sf[5] = dm / g; sf[6] += 0.1 * (sf[5] - sf[6])
            sf[9] += (abs(dm) - sf[9]) / max(nU, 1)
            z = dm / (sf[9] + 1e-9)
            sf[10] = max(0.0, sf[10] + z - 0.05); sf[11] = max(0.0, sf[11] - z - 0.05)
        ring_m[nU % RING] = mt; ring_t[nU % RING] = t; si[5] = nU + 1; si[6] = t
    nU = si[5]
    for i in range(4):
        K = KS[i]
        if nU - 1 - K >= 0:
            j = (nU - 1 - K) % RING; out[10 + i] = mt - ring_m[j]; out[14 + i] = np.log1p(t - ring_t[j])
        else:
            out[10 + i] = mt - ring_m[0]; out[14 + i] = np.log1p(t)
    ng = min(nU - 1, 8)
    if ng > 0:
        s = 0.0
        for i in range(ng): s += gaps[i]
        out[18] = np.log(s / ng)
        out[19] = np.log1p(t - si[6]) - np.log1p(sf[4] / (nU - 1))
    else:
        out[18] = 0.0; out[19] = 0.0
    out[20] = sf[5]; out[21] = sf[6]
    for b in range(3):
        col = 0 if b == 0 else (11 if b == 1 else 44)
        k = np.int64(np.round(np.float64(x[col]) * 1e5))
        d = d0 if b == 0 else (d1 if b == 1 else d2)
        if k in d:
            sl = d[k]; new = 0.0; since = t - last[b, sl]
        else:
            sl = len(d); d[k] = sl; new = 1.0; since = 20000
        cnt[b, sl] += 1; last[b, sl] = t
        out[22 + 5 * b] = np.log1p(cnt[b, sl]); out[23 + 5 * b] = cnt[b, sl] / (t + 1)
        out[24 + 5 * b] = np.log1p(since); out[25 + 5 * b] = new; out[26 + 5 * b] = np.log1p(len(d))
        if b == 0: slot_hist[t] = sl
    for hi in range(2):
        h = 100 if hi == 0 else 300
        if t - h >= 0:
            s0 = slot_hist[t - h]; osum[hi, s0] += mt - m_hist[t - h]; on[hi, s0] += 1
        sl = slot_hist[t]
        out[37 + hi] = osum[hi, sl] / (on[hi, sl] + 3.0)
    out[39] = np.log1p(on[0, slot_hist[t]]); out[40] = np.log1p(on[1, slot_hist[t]])
    if t == 0:
        sf[7] = mt; sf[8] = mt; si[7] = 0; si[8] = 0
    if mt >= sf[7]: sf[7] = mt; si[7] = t
    if mt <= sf[8]: sf[8] = mt; si[8] = t
    out[41] = (mt - sf[8]) / (sf[7] - sf[8] + 1e-9); out[42] = np.log1p(t - si[7]); out[43] = np.log1p(t - si[8])
    for i in range(3):
        v = np.float64(x[SLOW[i]])
        if t == 0: sf[12 + i] = v
        sf[12 + i] += (v - sf[12 + i]) / 5000.0; sf[15 + i] += (v - sf[15 + i]) / (t + 1)
        out[44 + 2 * i] = v - sf[12 + i]; out[45 + 2 * i] = v - sf[15 + i]
    out[50] = min(sf[10], 8.0); out[51] = min(sf[11], 8.0)


# ============================================================== LightGBM trees as arrays
@njit(cache=True)
def trees_predict(z, feat, thr, left, right, leafv, roots):
    """Sum of tree outputs. Internal nodes: feat/thr/left/right; child < 0 means leaf index ~child."""
    tot = 0.0
    for t in range(roots.shape[0]):
        nd = roots[t]
        while nd >= 0:
            if np.float64(z[feat[nd]]) <= thr[nd]: nd = left[nd]
            else: nd = right[nd]
        tot += leafv[~nd]
    return tot


# ============================================================== minGRU (stack of layers, see the module docstring)
@njit(fastmath=True, cache=True)
def _layernorm(u, w, b, out):
    H = u.shape[0]; m = 0.0
    for i in range(H): m += u[i]
    m /= H; v = 0.0
    for i in range(H):
        d = u[i] - m; v += d * d
    inv = 1.0 / math.sqrt(v / H + 1e-5)
    for i in range(H): out[i] = (u[i] - m) * inv * w[i] + b[i]


@njit(fastmath=True, cache=True)
def _matvec_s_nb(W, sc, x, b, out):
    """out = b + sc * (W . x); W float32 (sc = 1) or int8 with one scale per output row (8-bit weights: 4x less memory)."""
    for i in range(W.shape[0]):
        s = np.float32(0.0)                          # float32 accumulation (a float64 accumulator is much slower)
        for j in range(W.shape[1]):
            s += np.float32(W[i, j]) * x[j]
        out[i] = b[i] + sc[i] * s


def _matvec_s(W, sc, x, b, out):   # dispatcher: C for int8 weights when it compiled, else the Numba loop
    return _matvec_s_nb(W, sc, x, b, out)


@overload(_matvec_s)
def _ov_matvec_s(W, sc, x, b, out):
    if USE_C and isinstance(W, types.Array) and W.dtype == types.int8:
        def impl(W, sc, x, b, out):
            _CMV(W.ctypes.data, W.strides[0], sc.ctypes.data, x.ctypes.data, b.ctypes.data, out.ctypes.data, W.shape[0], W.shape[1])
        return impl
    def impl(W, sc, x, b, out):
        _matvec_s_nb(W, sc, x, b, out)
    return impl


@njit(fastmath=True, cache=True)
def _layers_nb(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold):
    H = u.shape[0]; sgn = fold >= 2   # BIGSWARM: bit 2 of fold = signed candidate
    for l in range(L):
        _layernorm(u, ln1w[l], ln1b[l], t1)
        _matvec_s(Gw[l], Gs[l], t1, Gb[l], g2)
        for i in range(H):
            z = _sig_t(g2[i]); c = g2[H + i]
            gc = (2.0 * _sig_t(2.0 * c) - 1.0) if sgn else (c + 0.5 if c >= 0.0 else _sig_t(c))
            h[l, i] = (1.0 - z) * h[l, i] + z * gc
            u[i] += h[l, i]
        _layernorm(u, ln2w[l], ln2b[l], t1)
        _matvec_s(M1w[l], M1s[l], t1, M1b[l], g2)
        for i in range(M1w.shape[1]): g2[i] = _gelu_t(g2[i])   # MLP width from the weights (SLIM: 1x or 2x)
        _matvec_s(M2w[l], M2s[l], g2, M2b[l], t3)
        for i in range(H): u[i] += t3[i]


def _layers(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold):   # dispatcher
    return _layers_nb(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold)


@overload(_layers)
def _ov_layers(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold):
    if USE_C and Gw.dtype == types.int8 and M1w.dtype == types.int8 and M2w.dtype == types.int8:
        def impl(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold):
            _CMG(L, u.shape[0], M1w.shape[1],
                 Gw.ctypes.data, Gw.strides[0], Gw.strides[1], Gs.ctypes.data, Gb.ctypes.data, Gs.strides[0] // 4,
                 M1w.ctypes.data, M1w.strides[0], M1w.strides[1], M1s.ctypes.data, M1b.ctypes.data, M1s.strides[0] // 4,
                 M2w.ctypes.data, M2w.strides[0], M2w.strides[1], M2s.ctypes.data, M2b.ctypes.data, M2s.strides[0] // 4,
                 ln1w.ctypes.data, ln1b.ctypes.data, ln2w.ctypes.data, ln2b.ctypes.data, ln1w.strides[0] // 4,
                 h.ctypes.data, h.strides[0] // 4, u.ctypes.data, _SIG_T.ctypes.data, _ERF_T.ctypes.data, fold, g2.ctypes.data)
        return impl
    def impl(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold):
        _layers_nb(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold)   # never folds
    return impl


@njit(fastmath=True, cache=True)
def _head_nb(R, H, W, Hw, MF, Hb, u, g2, t3, fold):
    for r in range(R):
        s = Hb[r]
        for j in range(H): s += Hw[r, j] * u[j]
        if fold & 1:
            for k in range(W): s += MF[r, k] * g2[k]
        t3[r] = s


def _head(R, H, W, Hw, MF, Hb, u, g2, t3, fold):
    return _head_nb(R, H, W, Hw, MF, Hb, u, g2, t3, fold)


@overload(_head)
def _ov_head(R, H, W, Hw, MF, Hb, u, g2, t3, fold):
    if USE_C:
        def impl(R, H, W, Hw, MF, Hb, u, g2, t3, fold):
            _CHD(R, H, W, Hw.ctypes.data, Hw.strides[0] // 4, MF.ctypes.data, MF.strides[0] // 4, Hb.ctypes.data,
                 u.ctypes.data, g2.ctypes.data, t3.ctypes.data, fold)
        return impl
    def impl(R, H, W, Hw, MF, Hb, u, g2, t3, fold):
        _head_nb(R, H, W, Hw, MF, Hb, u, g2, t3, fold)
    return impl


@njit(fastmath=True, cache=_CACHE)
def mingru_step(inp, PT, ncol, cols, pb, PX, LAST, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, Hw, Hb, mixK, h, u, t1, g2, t3, out, MF, fold):
    """One row of one minGRU. PX (H, float64) = running input projection (incremental over changed columns); h (L, H)."""
    H = u.shape[0]; L = h.shape[0]
    for q in range(ncol):
        j = cols[q]; v = inp[j]; dv = v - LAST[j]
        if dv != 0.0:
            LAST[j] = v; row = PT[j]
            for i in range(H): PX[i] += np.float64(row[i]) * dv
    for i in range(H): u[i] = pb[i] + np.float32(PX[i])
    _layers(L, ln1w, ln1b, Gw, Gs, Gb, ln2w, ln2b, M1w, M1s, M1b, M2w, M2s, M2b, h, u, t1, g2, t3, fold)
    W_ = M1w.shape[1]
    if mixK == 0:
        _head(2, H, W_, Hw, MF, Hb, u, g2, t3, fold)
        z0 = t3[0]; z1 = t3[1]
        out[0] = z0 - z1; out[1] = -z0 - z1
    else:   # mixture head: logits of K situations, then (t0, t1) per situation; output = expectation
        K = mixK if mixK > 0 else -mixK   # MIXTILT: mix = -K = tilted readout, factors a (K, 2) in Hb[3K:5K]
        _head(3 * K, H, W_, Hw, MF, Hb, u, g2, t3, fold)   # logits / values in t3 (g2 holds the folded GELU output)
        mx = t3[0]
        for k in range(1, K): mx = max(mx, t3[k])
        d0 = 0.0; d1 = 0.0; o0 = 0.0; o1 = 0.0
        for k in range(K):
            e = math.exp(t3[k] - mx); e0 = e; e1 = e
            if mixK < 0:
                e0 = e * Hb[3 * K + 2 * k]; e1 = e * Hb[3 * K + 2 * k + 1]
            d0 += e0; d1 += e1; o0 += e0 * t3[K + 2 * k]; o1 += e1 * t3[K + 2 * k + 1]
        out[0] = o0 / d0; out[1] = o1 / d1


@njit(cache=True)
def _ED():   # SPEED2: an empty int->int dict made inside compiled code (the corrector's dicts, unused when it is off)
    return Dict.empty(key_type=types.int64, value_type=types.int64)


# ============================================================== fused per-row kernel (one Python -> Numba call per row)
@njit(fastmath=True, cache=True)
def gru_step_sparse(inp, W0T, ncol, cols, b0, R0, c0, W1, b1, R1, c1, Wh, bh, h0, h1, gx, tmp, out, gxin, last):
    """As gru_step, but the input layer W0 . inp is kept from the previous row (gxin, float64) and updated only for the
    used input columns (cols[:ncol]) whose value changed since then (last = their previous values). At a sequence
    start gxin and last are zero, so the first row computes the full product."""
    H = h0.shape[0]; G3 = gx.shape[0]
    for q in range(ncol):
        j = cols[q]; v = inp[j]; dv = v - last[j]
        if dv != 0.0:
            last[j] = v; row = W0T[j]
            for i in range(G3): gxin[i] += np.float64(row[i]) * dv
    for i in range(G3): gx[i] = b0[i] + np.float32(gxin[i])
    _gru_update(gx, h0, R0, c0, tmp, H)
    _matvec(W1, h0, b1, gx); _gru_update(gx, h1, R1, c1, tmp, H)
    z0 = bh[0]; z1 = bh[1]
    for j in range(H):
        z0 += Wh[0, j] * h1[j]; z1 += Wh[1, j] * h1[j]
    out[0] = z0 - z1; out[1] = -z0 - z1


@njit(cache=_CACHE)
def step_all(x, t, inp, prev, sc, fid, has_reg, inp2, xr, prevr, rates, m500, m2000, held, med_r, lo_r, hi_r, sent_r, zero_r,
             W0T, ncol, cols, b0, R0, c0, W1, b1, R1, c1, Wh, bh, H0, H1, gx, tmp, PG, GXIN, LAST,
             mfid, MPT, Mncol, Mcols, Mpb, MPX, MLAST, Mln1w, Mln1b, MGw, MGs, MGb, Mln2w, Mln2b, MM1w, MM1s, MM1b, MM2w, MM2s, MM2b, MHw, MHb, Mmix, MF, mfold, Msgn,
             MH, Mu, Mt1, Mg2, Mt3, PM, MHd, MWd, MLd, MPres, MQT, MQb1, MQW2, MQb2, MQX, MQLAST, Mq, use_win, use_corr,
             f, xc, wprev, m3, since, act, femas, gap_e, mq, sent_cols, zero_cols, med, lo, hi, groups,
             w1_mu, w1_isd, fn, M0, m0, M1, m1, M2, m2, M3, m3b, hA, hB, hC, w1out,
             xp, e2, sf, si, ring_m, ring_t, gaps, cnt, last, osum, on, slot_hist, m_hist, d0, d1, d2,
             mub, vb, sdb, mua, va, sda, KS, SLOW,
             beta0, beta1, scale, z,
             f0, th0, l0, r0, v0, ro0, f1, th1, l1, r1, v1, ro1, out):
    first = t == 0
    build_raw_d1(x, prev, first, inp, sc)
    if has_reg:
        reg_row(x, first, inp2, xr, prevr, rates, m500, m2000, held, sent_r, zero_r, med_r, lo_r, hi_r)
    G = W0T.shape[0]; MN = MPT.shape[0]
    if first:
        for g in range(G):
            for i in range(GXIN.shape[1]): GXIN[g, i] = 0.0
            for j in range(LAST.shape[1]): LAST[g, j] = 0.0
        for g in range(MN):
            for i in range(MPX.shape[1]): MPX[g, i] = 0.0
            for j in range(MLAST.shape[1]): MLAST[g, j] = 0.0
            for l in range(MH.shape[1]):
                for i in range(MH.shape[2]): MH[g, l, i] = 0.0
            for i in range(MQX.shape[1]): MQX[g, i] = 0.0
            for j in range(MQLAST.shape[1]): MQLAST[g, j] = 0.0
    for g in range(G):
        src = inp2 if fid[g] == 1 else inp
        gru_step_sparse(src, W0T[g], ncol[g], cols[g], b0[g], R0[g], c0[g], W1[g], b1[g], R1[g], c1[g], Wh[g], bh[g],
                        H0[g], H1[g], gx, tmp, PG[g], GXIN[g], LAST[g])
    for gg in range(MN):
        g = gg if (t & 1) == 0 else MN - 1 - gg   # CACHE: alternate member order each row (independent members: exact)
        src = inp2 if mfid[g] == 1 else inp
        H_ = MHd[g]; W_ = MWd[g]; L_ = MLd[g]   # MIXW: members of different widths / depths share padded arrays; exact-size views
        mingru_step(src, MPT[g][:, :H_], Mncol[g], Mcols[g], Mpb[g][:H_], MPX[g][:H_], MLAST[g], Mln1w[g][:L_, :H_], Mln1b[g][:L_, :H_],
                    MGw[g][:L_, :2 * H_, :H_], MGs[g][:L_, :2 * H_], MGb[g][:L_, :2 * H_], Mln2w[g][:L_, :H_], Mln2b[g][:L_, :H_],
                    MM1w[g][:L_, :W_, :H_], MM1s[g][:L_, :W_], MM1b[g][:L_, :W_], MM2w[g][:L_, :H_, :W_], MM2s[g][:L_, :H_], MM2b[g][:L_, :H_],
                    MHw[g][:, :H_], MHb[g], Mmix[g], MH[g][:L_, :H_], Mu[:H_], Mt1, Mg2, Mt3, PM[g], MF[g][:, :W_], mfold + 2 * Msgn[g])
        P_ = MPres[g]
        if P_ > 0:   # PRESENT: current-row-only head (Linear -> GELU -> Linear) added to the output; first layer kept incrementally
            QT = MQT[g]; QX = MQX[g]; QL = MQLAST[g]; cl = Mcols[g]
            for q in range(Mncol[g]):
                j = cl[q]; v = src[j]; dv = v - QL[j]
                if dv != 0.0:
                    QL[j] = v; row = QT[j]
                    for i in range(P_): QX[i] += np.float64(row[i]) * dv
            for i in range(P_):
                a_ = MQb1[g, i] + np.float32(QX[i]); Mq[i] = _gelu_t(a_)
            for k in range(2):
                s_ = MQb2[g, k]
                for i in range(P_): s_ += MQW2[g, k, i] * Mq[i]
                PM[g, k] += s_
    if use_win:
        w1d_feat_row(x, first, f, xc, wprev, m3, since, act, femas, gap_e, mq, sent_cols, zero_cols, med, lo, hi, groups)
        mlp_row(f, w1_mu, w1_isd, fn, M0, m0, M1, m1, M2, m2, M3, m3b, hA, hB, hC, w1out)
    if use_corr:
        evt2_step(x, xp, t, e2, sf, si, ring_m, ring_t, gaps, cnt, last, osum, on, slot_hist, m_hist, d0, d1, d2,
                  mub, vb, sdb, mua, va, sda, KS, SLOW)
        for c in range(112): xp[c] = x[c]
    NM = G + MN + 1
    for k in range(2):
        b = beta0 if k == 0 else beta1
        base = b[NM]
        for i in range(G):
            base += b[i] * PG[i, k]; z[i] = PG[i, k]
        for i in range(MN):
            base += b[G + i] * PM[i, k]; z[G + i] = PM[i, k]
        base += b[G + MN] * w1out[k]; z[G + MN] = w1out[k]
        tr = 0.0
        if use_corr:
            for j in range(e2.shape[0]): z[NM + j] = e2[j]
            if k == 0: tr = trees_predict(z, f0, th0, l0, r0, v0, ro0)
            else: tr = trees_predict(z, f1, th1, l1, r1, v1, ro1)
        out[k] = (base + tr) * scale



_ROW_SRC = r"""
// ROWC (2026-10-26): the whole per-row step of a minGRU-only package in C, as a CPython extension type whose predict(dp)
// is bound directly as model.predict (no Python frame per row). Built at load from the package's _C_SRC (included as
// core.c: mvp / mg_layers / head_rows) + this file. Merged from two prototypes (explore/rowc/README): rowstep (extension,
// state in C, bit-identical) and c_step (register-blocked incremental projection). -DDRIFTFIX computes the projection's
// input step in float64 (exact, no drift over 20,000 rows; otherwise float32 like the Numba path, bit-identical to it).
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION
#include <numpy/arrayobject.h>
#include "core.c"
#undef free

#define MAXM 8
#ifdef PT16   /* PT16: projection weights int16 per input column, scale per column */
typedef int16_t PTT;
#define LDP(p) _mm512_cvtepi32_pd(_mm256_cvtepi16_epi32(_mm_loadu_si128((const __m128i*)(p))))
#else
typedef float PTT;
#define LDP(p) _mm512_cvtps_pd(_mm256_loadu_ps(p))
#endif
typedef struct {
    int H, W, L, K, ncol, fold;
    const PTT* PT; long ldpt; const float* PTs; const int64_t* cols; const float* pb;
    const int8_t* Gw; long Gl, Gr; const float *Gs, *Gb; long Gv;
    const int8_t* M1w; long M1l, M1r; const float *M1s, *M1b; long M1v;
    const int8_t* M2w; long M2l, M2r; const float *M2s, *M2b; long M2v;
    const float *l1w, *l1b, *l2w, *l2b; long lv;
    const float* Hw; long ldh; const float* MF; long ldf; const float* Hb;
    long nlast;
    double* PX; float* LAST; float* h; long hl;     // state, owned
    float PM[2];
} Member;
typedef struct {        // GRU member (e.g. the organisers' baseline, ported): weights int8 per row (quantised at load)
    int H, ncol; const PTT* W0T; long ldw0; const float* W0s; const int64_t* cols; const float *b0, *c0, *b1, *c1, *Wh, *bh;
    const int8_t *R0q, *W1q, *R1q; const float *R0s, *W1s, *R1s; long nlast;
    double* gxin; float *last, *h0, *h1; float PG[2];
} GMember;
typedef struct {
    int MN, NG, NM, nsc; const int64_t* sc; const double *SIG, *ERF;
    double beta0[64], beta1[64], scale;
    float inp[512], prev[112];
    float u[MAXC / 4], g2[MAXC / 4], t3[MAXC / 4];
    long t, cur; int have_cur;
    float out[2];
    Member m[MAXM];
    GMember gm[4];
} Model;
static const float SENTF = -5.199337f;
static PyObject *s_seq, *s_step, *s_need, *s_state;

/* incremental input projection, register-blocked (changed columns gathered first; PX kept in registers across them).
   Per element the same summation order as the Numba loop. */
static void proj_core(const float* inp, int H, int ncol, const int64_t* cols, const PTT* PT, long ldp, const float* PS, double* PX, float* LAST,
                      const float* pb, float* u) {
    int J[1024]; double D[1024]; int n = 0;
    for (int q = 0; q < ncol; q++) { const int j = (int)cols[q]; const float v = inp[j];
#ifdef DRIFTFIX
        const float lv = LAST[j]; if (v != lv) { LAST[j] = v; J[n] = j; D[n] = (double)v - (double)lv; n++; }
#else
        const float dv = v - LAST[j]; if (dv != 0.0f) { LAST[j] = v; J[n] = j; D[n] = (double)dv; n++; }
#endif
    }
#ifdef PT16
    for (int k = 0; k < n; k++) D[k] *= (double)PS[J[k]];
#endif
    int i = 0;
#if defined(__AVX512F__)
    for (; i + 64 <= H; i += 64) {
        __m512d a0 = _mm512_loadu_pd(PX + i), a1 = _mm512_loadu_pd(PX + i + 8), a2 = _mm512_loadu_pd(PX + i + 16), a3 = _mm512_loadu_pd(PX + i + 24),
                a4 = _mm512_loadu_pd(PX + i + 32), a5 = _mm512_loadu_pd(PX + i + 40), a6 = _mm512_loadu_pd(PX + i + 48), a7 = _mm512_loadu_pd(PX + i + 56);
        for (int k = 0; k < n; k++) { const PTT* r = PT + (long)J[k] * ldp + i; __m512d d = _mm512_set1_pd(D[k]);
            a0 = _mm512_fmadd_pd(LDP(r), d, a0);      a1 = _mm512_fmadd_pd(LDP(r + 8), d, a1);
            a2 = _mm512_fmadd_pd(LDP(r + 16), d, a2); a3 = _mm512_fmadd_pd(LDP(r + 24), d, a3);
            a4 = _mm512_fmadd_pd(LDP(r + 32), d, a4); a5 = _mm512_fmadd_pd(LDP(r + 40), d, a5);
            a6 = _mm512_fmadd_pd(LDP(r + 48), d, a6); a7 = _mm512_fmadd_pd(LDP(r + 56), d, a7); }
        _mm512_storeu_pd(PX + i, a0); _mm512_storeu_pd(PX + i + 8, a1); _mm512_storeu_pd(PX + i + 16, a2); _mm512_storeu_pd(PX + i + 24, a3);
        _mm512_storeu_pd(PX + i + 32, a4); _mm512_storeu_pd(PX + i + 40, a5); _mm512_storeu_pd(PX + i + 48, a6); _mm512_storeu_pd(PX + i + 56, a7);
    }
#endif
    for (; i < H; i += 16) { const int e = H - i < 16 ? H - i : 16; double a[16];
        for (int t = 0; t < e; t++) a[t] = PX[i + t];
        for (int k = 0; k < n; k++) { const PTT* r = PT + (long)J[k] * ldp + i; for (int t = 0; t < e; t++) a[t] += (double)r[t] * D[k]; }
        for (int t = 0; t < e; t++) PX[i + t] = a[t]; }
    for (int i2 = 0; i2 < H; i2++) u[i2] = pb[i2] + (float)PX[i2];
}
static void proj_inc(const float* inp, Member* g, float* u) {
    proj_core(inp, g->H, g->ncol, g->cols, g->PT, g->ldpt, g->PTs, g->PX, g->LAST, g->pb, u);
}

static void member_step(Model* M, Member* g) {
    const int H = g->H;
    proj_inc(M->inp, g, M->u);
    mg_layers(g->L, H, g->W, g->Gw, g->Gl, g->Gr, g->Gs, g->Gb, g->Gv, g->M1w, g->M1l, g->M1r, g->M1s, g->M1b, g->M1v,
              g->M2w, g->M2l, g->M2r, g->M2s, g->M2b, g->M2v, g->l1w, g->l1b, g->l2w, g->l2b, g->lv,
              g->h, g->hl, M->u, M->SIG, M->ERF, g->fold, M->g2);
    float* t3 = M->t3;
    if (g->K == 0) {
        head_rows(2, H, g->W, g->Hw, g->ldh, g->MF, g->ldf, g->Hb, M->u, M->g2, t3, g->fold);
        g->PM[0] = t3[0] - t3[1]; g->PM[1] = -t3[0] - t3[1];
    } else {
        const int K = g->K < 0 ? -g->K : g->K;   /* MIXTILT: K < 0 = tilted readout, factors a (K, 2) in Hb[3K:5K] */
        head_rows(3 * K, H, g->W, g->Hw, g->ldh, g->MF, g->ldf, g->Hb, M->u, M->g2, t3, g->fold);
        float mx = t3[0]; for (int k = 1; k < K; k++) mx = t3[k] > mx ? t3[k] : mx;
        double d0 = 0.0, d1 = 0.0, o0 = 0.0, o1 = 0.0; const float* A = g->K < 0 ? g->Hb + 3 * K : NULL;
        for (int k = 0; k < K; k++) { float e = expf(t3[k] - mx); float e0 = A ? e * A[2 * k] : e, e1 = A ? e * A[2 * k + 1] : e;
            d0 += e0; d1 += e1; o0 += (double)(e0 * t3[K + 2 * k]); o1 += (double)(e1 * t3[K + 2 * k + 1]); }
        g->PM[0] = (float)(o0 / d0); g->PM[1] = (float)(o1 / d1);
    }
}

static void gru_upd(const float* gx, const float* tmp, float* h, int H) {   /* PyTorch gate order r, z, n */
    for (int i = 0; i < H; i++) {
        double r = 1.0 / (1.0 + exp(-((double)gx[i] + (double)tmp[i]))), z = 1.0 / (1.0 + exp(-((double)gx[H + i] + (double)tmp[H + i])));
        double n = tanh((double)gx[2 * H + i] + r * (double)tmp[2 * H + i]);
        h[i] = (float)((1.0 - z) * n + z * (double)h[i]);
    }
}
static void gru_member(Model* M, GMember* g) {
    const int H = g->H, G3 = 3 * H; float* gx = M->g2; float* tmp = M->t3;
    proj_core(M->inp, G3, g->ncol, g->cols, g->W0T, g->ldw0, g->W0s, g->gxin, g->last, g->b0, gx);
    MVSEL(g->R0q, H, g->R0s, g->h0, g->c0, tmp, G3, H); gru_upd(gx, tmp, g->h0, H);
    MVSEL(g->W1q, H, g->W1s, g->h0, g->b1, gx, G3, H); MVSEL(g->R1q, H, g->R1s, g->h1, g->c1, tmp, G3, H); gru_upd(gx, tmp, g->h1, H);
    float z0 = g->bh[0], z1 = g->bh[1];
    for (int j = 0; j < H; j++) { z0 += g->Wh[j] * g->h1[j]; z1 += g->Wh[H + j] * g->h1[j]; }
    g->PG[0] = z0 - z1; g->PG[1] = -z0 - z1;
}

static void row_step(Model* M, const float* x) {
    const int first = M->t == 0;
    for (int c = 0; c < 112; c++) { M->inp[c] = x[c]; M->inp[112 + c] = first ? 0.0f : x[c] - M->prev[c]; M->prev[c] = x[c]; }
    for (int k = 0; k < M->nsc; k++) M->inp[224 + k] = ((double)fabsf(x[M->sc[k]] - SENTF) < 1e-3) ? 1.0f : 0.0f;
    if (first) for (int i = 0; i < M->MN; i++) { Member* g = &M->m[i];
        memset(g->PX, 0, sizeof(double) * g->H); memset(g->LAST, 0, sizeof(float) * g->nlast); memset(g->h, 0, sizeof(float) * g->L * g->hl); }
    if (first) for (int i = 0; i < M->NG; i++) { GMember* g = &M->gm[i];
        memset(g->gxin, 0, sizeof(double) * 3 * g->H); memset(g->last, 0, sizeof(float) * g->nlast);
        memset(g->h0, 0, sizeof(float) * g->H); memset(g->h1, 0, sizeof(float) * g->H); }
    for (int i = 0; i < M->NG; i++) gru_member(M, &M->gm[i]);
    for (int gg = 0; gg < M->MN; gg++) member_step(M, &M->m[(M->t & 1) == 0 ? gg : M->MN - 1 - gg]);
    for (int k = 0; k < 2; k++) {
        const double* b = k == 0 ? M->beta0 : M->beta1; double base = b[M->NM];
        for (int i = 0; i < M->NG; i++) base += b[i] * (double)M->gm[i].PG[k];
        for (int i = 0; i < M->MN; i++) base += b[M->NG + i] * (double)M->m[i].PM[k];
        float o = (float)(base * M->scale);                     // (W1D / corrector members are off in supported packages)
        M->out[k] = o > 2.0f ? 2.0f : (o < -2.0f ? -2.0f : o);
    }
    M->t++;
}

// ---------------------------------------------------------------- the Python type
typedef struct { PyObject_HEAD Model* M; PyObject* keep; } Stepper;

static void St_dealloc(Stepper* s) {
    if (s->M) { for (int i = 0; i < s->M->MN; i++) { free(s->M->m[i].PX); free(s->M->m[i].LAST); free(s->M->m[i].h); }
        for (int i = 0; i < s->M->NG; i++) { free(s->M->gm[i].gxin); free(s->M->gm[i].last); free(s->M->gm[i].h0); free(s->M->gm[i].h1); } free(s->M); }
    Py_XDECREF(s->keep); Py_TYPE(s)->tp_free((PyObject*)s);
}

static PyObject* new_out(const float* o) {
    npy_intp d = 2; PyObject* r = PyArray_SimpleNew(1, &d, NPY_FLOAT32); if (!r) return NULL;
    memcpy(PyArray_DATA((PyArrayObject*)r), o, 8); return r;
}

static PyObject* St_predict(Stepper* self, PyObject* dp) {
    Model* M = self->M;
    PyObject* o = PyObject_GetAttr(dp, s_seq); if (!o) return NULL;
    long seq = PyLong_AsLong(o); Py_DECREF(o); if (seq == -1 && PyErr_Occurred()) return NULL;
    if (!M->have_cur || seq != M->cur) {
        o = PyObject_GetAttr(dp, s_step); if (!o) return NULL; long st = PyLong_AsLong(o); Py_DECREF(o);
        if (st == -1 && PyErr_Occurred()) return NULL;
        if (st != 0) { PyErr_SetString(PyExc_ValueError, "a new sequence must start at step zero"); return NULL; }
        M->cur = seq; M->have_cur = 1; M->t = 0;
    }
    PyObject* s = PyObject_GetAttr(dp, s_state); if (!s) return NULL;
    PyArrayObject* A = (PyArrayObject*)s;
    if (PyArray_Check(s) && PyArray_TYPE(A) == NPY_FLOAT32 && PyArray_IS_C_CONTIGUOUS(A) && PyArray_SIZE(A) == 112) {
        row_step(M, (const float*)PyArray_DATA(A)); Py_DECREF(s);
    } else {
        PyObject* c = PyArray_FROMANY(s, NPY_FLOAT32, 1, 1, NPY_ARRAY_CARRAY_RO | NPY_ARRAY_FORCECAST); Py_DECREF(s); if (!c) return NULL;
        if (PyArray_SIZE((PyArrayObject*)c) != 112) { Py_DECREF(c); PyErr_SetString(PyExc_ValueError, "state must have 112 values"); return NULL; }
        row_step(M, (const float*)PyArray_DATA((PyArrayObject*)c)); Py_DECREF(c);
    }
    o = PyObject_GetAttr(dp, s_need); if (!o) return NULL; int need = PyObject_IsTrue(o); Py_DECREF(o);
    if (need < 0) return NULL;
    if (!need) Py_RETURN_NONE;
    return new_out(M->out);
}

static PyObject* St_run_seq(Stepper* self, PyObject* a) {   // tests: a whole (n, 112) sequence from step 0, returns (n, 2)
    PyArrayObject* X = (PyArrayObject*)PyArray_FROMANY(a, NPY_FLOAT32, 2, 2, NPY_ARRAY_CARRAY_RO); if (!X) return NULL;
    npy_intp n = PyArray_DIM(X, 0), d[2] = {n, 2}; PyObject* R = PyArray_SimpleNew(2, d, NPY_FLOAT32);
    if (!R) { Py_DECREF(X); return NULL; }
    const float* x = (const float*)PyArray_DATA(X); float* r = (float*)PyArray_DATA((PyArrayObject*)R);
    Model* M = self->M; M->t = 0; M->have_cur = 0;
    for (npy_intp t = 0; t < n; t++) { row_step(M, x + t * 112); r[2 * t] = M->out[0]; r[2 * t + 1] = M->out[1]; }
    Py_DECREF(X); return R;
}

static PyMethodDef St_methods[] = {{"predict", (PyCFunction)St_predict, METH_O, ""}, {"run_seq", (PyCFunction)St_run_seq, METH_O, ""}, {NULL, NULL, 0, NULL}};
static PyTypeObject StepperType = {PyVarObject_HEAD_INIT(NULL, 0)};

// new(I int64, F float64, keep) -> Stepper. I layout: MN, NG, NM, nsc, sc*, SIG*, ERF*, then 46 values per member (see Python cfg).
static PyObject* mod_new(PyObject* self, PyObject* args) {
    PyArrayObject *IA, *FA; PyObject* keep;
    if (!PyArg_ParseTuple(args, "O!O!O", &PyArray_Type, &IA, &PyArray_Type, &FA, &keep)) return NULL;
    if (PyArray_TYPE(IA) != NPY_INT64 || PyArray_TYPE(FA) != NPY_FLOAT64) { PyErr_SetString(PyExc_TypeError, "I int64, F float64"); return NULL; }
    const int64_t* a = (const int64_t*)PyArray_DATA(IA); const double* f = (const double*)PyArray_DATA(FA);
    Model* M = (Model*)calloc(1, sizeof(Model)); if (!M) return PyErr_NoMemory();
    int p = 0; M->MN = (int)a[p++]; M->NG = (int)a[p++]; M->NM = (int)a[p++]; M->nsc = (int)a[p++];
    M->sc = (const int64_t*)a[p++]; M->SIG = (const double*)a[p++]; M->ERF = (const double*)a[p++];
    if (M->MN > MAXM || M->MN < 1 || M->NG > 4 || M->NG < 0 || M->NM + 1 > 64) { free(M); PyErr_SetString(PyExc_ValueError, "member count"); return NULL; }
    for (int i = 0; i < M->MN; i++) { Member* g = &M->m[i];
        g->H = (int)a[p++]; g->W = (int)a[p++]; g->L = (int)a[p++]; g->K = (int)a[p++]; g->ncol = (int)a[p++]; g->fold = (int)a[p++];
        g->PT = (const PTT*)a[p++]; g->ldpt = a[p++]; g->cols = (const int64_t*)a[p++]; g->pb = (const float*)a[p++]; g->PTs = NULL;
#ifdef PT16
        g->PTs = (const float*)a[p++];
#endif
       
        g->Gw = (const int8_t*)a[p++]; g->Gl = a[p++]; g->Gr = a[p++]; g->Gs = (const float*)a[p++]; g->Gb = (const float*)a[p++]; g->Gv = a[p++];
        g->M1w = (const int8_t*)a[p++]; g->M1l = a[p++]; g->M1r = a[p++]; g->M1s = (const float*)a[p++]; g->M1b = (const float*)a[p++]; g->M1v = a[p++];
        g->M2w = (const int8_t*)a[p++]; g->M2l = a[p++]; g->M2r = a[p++]; g->M2s = (const float*)a[p++]; g->M2b = (const float*)a[p++]; g->M2v = a[p++];
        g->l1w = (const float*)a[p++]; g->l1b = (const float*)a[p++]; g->l2w = (const float*)a[p++]; g->l2b = (const float*)a[p++]; g->lv = a[p++];
        g->Hw = (const float*)a[p++]; g->ldh = a[p++]; g->MF = (const float*)a[p++]; g->ldf = a[p++]; g->Hb = (const float*)a[p++];
        g->nlast = a[p++]; g->hl = a[p++];
        if (g->H > MAXC / 8 || g->W > MAXC / 4 || 5 * (g->K < 0 ? -g->K : g->K) > MAXC / 4 || g->ncol > 1024) { free(M); PyErr_SetString(PyExc_ValueError, "member too wide"); return NULL; }
        g->PX = (double*)calloc(g->H, sizeof(double)); g->LAST = (float*)calloc(g->nlast, sizeof(float)); g->h = (float*)calloc((size_t)g->L * g->hl, sizeof(float));
    }
    for (int i = 0; i < M->NG; i++) { GMember* g = &M->gm[i];
        g->H = (int)a[p++]; g->ncol = (int)a[p++]; g->W0T = (const PTT*)a[p++]; g->ldw0 = a[p++]; g->cols = (const int64_t*)a[p++]; g->W0s = NULL;
#ifdef PT16
        g->W0s = (const float*)a[p++];
#endif
       
        g->b0 = (const float*)a[p++]; g->c0 = (const float*)a[p++]; g->b1 = (const float*)a[p++]; g->c1 = (const float*)a[p++];
        g->Wh = (const float*)a[p++]; g->bh = (const float*)a[p++];
        g->R0q = (const int8_t*)a[p++]; g->R0s = (const float*)a[p++]; g->W1q = (const int8_t*)a[p++]; g->W1s = (const float*)a[p++];
        g->R1q = (const int8_t*)a[p++]; g->R1s = (const float*)a[p++]; g->nlast = a[p++];
        if (3 * g->H > MAXC / 4 || g->ncol > 1024) { free(M); PyErr_SetString(PyExc_ValueError, "GRU too wide"); return NULL; }
        g->gxin = (double*)calloc(3 * g->H, sizeof(double)); g->last = (float*)calloc(g->nlast, sizeof(float));
        g->h0 = (float*)calloc(g->H, sizeof(float)); g->h1 = (float*)calloc(g->H, sizeof(float));
    }
    if (p != PyArray_SIZE(IA)) { free(M); PyErr_Format(PyExc_ValueError, "layout mismatch %d vs %ld", p, (long)PyArray_SIZE(IA)); return NULL; }
    if (PyArray_SIZE(FA) != 2 * (M->NM + 1) + 1) { free(M); PyErr_SetString(PyExc_ValueError, "F size"); return NULL; }
    for (int i = 0; i <= M->NM; i++) { M->beta0[i] = f[i]; M->beta1[i] = f[M->NM + 1 + i]; }
    M->scale = f[2 * (M->NM + 1)];
    Stepper* s = PyObject_New(Stepper, &StepperType); if (!s) { free(M); return NULL; }
    s->M = M; Py_INCREF(keep); s->keep = keep; return (PyObject*)s;
}

static PyMethodDef MOD_METH[] = {{"new", mod_new, METH_VARARGS, ""}, {NULL, NULL, 0, NULL}};
static struct PyModuleDef MODDEF = {PyModuleDef_HEAD_INIT, "wnn_rowc", NULL, -1, MOD_METH};
PyMODINIT_FUNC PyInit_wnn_rowc(void) {
    import_array();
    StepperType.tp_name = "wnn_rowc.Stepper"; StepperType.tp_basicsize = sizeof(Stepper);
    StepperType.tp_dealloc = (destructor)St_dealloc; StepperType.tp_flags = Py_TPFLAGS_DEFAULT; StepperType.tp_methods = St_methods;
    if (PyType_Ready(&StepperType) < 0) return NULL;
    s_seq = PyUnicode_InternFromString("seq_ix"); s_step = PyUnicode_InternFromString("step_in_seq");
    s_need = PyUnicode_InternFromString("need_prediction"); s_state = PyUnicode_InternFromString("state");
    return PyModule_Create(&MODDEF);
}

"""


def _build_rowc():
    """ROWC: compile the whole-row C engine as a CPython extension (needs gcc, Python.h, numpy headers) -> (module, so) or None."""
    if not USE_C or os.environ.get("WNN_NO_ROWC") == "1": return None
    try:
        import sysconfig, importlib.machinery, importlib.util
        inc = sysconfig.get_paths()["include"]; npinc = np.get_include()
        if not os.path.exists(os.path.join(inc, "Python.h")) or not os.path.exists(os.path.join(npinc, "numpy", "arrayobject.h")): return None
        exact = os.environ.get("WNN_ROWC_EXACT") == "1"
        h = hashlib.md5((_C_SRC + _ROW_SRC + str(exact) + os.environ.get("WNN_TABLE_ACT", "") + os.environ.get("WNN_PT16", "1") + os.environ.get("WNN_FORCE_PATH", "")).encode()).hexdigest()[:10]
    except Exception:
        return None
    for d in (tempfile.gettempdir(), str(HERE), "/app/.cache"):
        try:
            dd = os.path.join(d, f"wnn_rowc_{h}_{os.getpid()}"); os.makedirs(dd, exist_ok=True)
            with open(os.path.join(dd, "core.c"), "w") as fh: fh.write(_C_SRC)
            with open(os.path.join(dd, "rowext.c"), "w") as fh: fh.write(_ROW_SRC)
            so = os.path.join(dd, "wnn_rowc" + sysconfig.get_config_var("EXT_SUFFIX"))
            subprocess.run(["gcc", "-O3", "-march=native", "-ffast-math", "-shared", "-fPIC", "-I" + inc, "-I" + npinc]
                           + ([] if exact else ["-DDRIFTFIX"]) + (["-DFORCE_PATH=" + os.environ["WNN_FORCE_PATH"]] if os.environ.get("WNN_FORCE_PATH") else []) + (["-DPT16"] if os.environ.get("WNN_PT16", "1") == "1" else []) + (["-DNO_VECACT"] if os.environ.get("WNN_TABLE_ACT") == "1" else [])
                           + [os.path.join(dd, "rowext.c"), "-o", so, "-lm"],
                           check=True, capture_output=True, timeout=180)
            return so
        except Exception:
            continue
    return None


def _load_rowc(so):
    import importlib.machinery, importlib.util
    ld = importlib.machinery.ExtensionFileLoader("wnn_rowc", so); sp = importlib.util.spec_from_loader("wnn_rowc", ld)
    mod = importlib.util.module_from_spec(sp); ld.exec_module(mod); return mod


def _rowc_supported(m):
    return (USE_C and len(m.gru) <= 4 and not m.use_win and not m.use_corr and not m.has_reg and len(m.mg_names) > 0
            and all(int(W[0].shape[0]) == 3 * int(W[2].shape[1]) for W in m.gru) and int((m.fid != 0).sum()) == 0
            and m.mquant and int((m.MPres > 0).sum()) == 0 and int((m.mfid != 0).sum()) == 0)


def _rowc_cfg(m):
    """flat int64 / float64 table for wnn_rowc.new: pointers to the model's own arrays, as the views step_all makes."""
    P = lambda a: a.ctypes.data
    PT16 = os.environ.get("WNN_PT16", "1") == "1"
    def q16(W):   # PT16: int16 per input column (row), float32 scale per row
        W = np.asarray(W, np.float32); s_ = (np.maximum(np.abs(W).max(1), 1e-30) / 32767.0).astype(np.float32)
        return np.ascontiguousarray(np.round(W / s_[:, None]).astype(np.int16)), np.ascontiguousarray(s_)
    MN = len(m.mg_names); I = [MN, len(m.gru), m.NM, len(m.sc), P(m.sc), P(_SIG_T), P(_ERF_T)]; keep = [m.sc, _SIG_T, _ERF_T]
    for g in range(MN):
        H_, W_ = int(m.MHd[g]), int(m.MWd[g])
        PT = m.MPT[g][:, :H_]; Gw = m.MGw[g][:, :2 * H_, :H_]; Gs = m.MGs[g][:, :2 * H_]; Gb = m.MGb[g][:, :2 * H_]
        M1w = m.MM1w[g][:, :W_, :H_]; M1s = m.MM1s[g][:, :W_]; M1b = m.MM1b[g][:, :W_]
        M2w = m.MM2w[g][:, :H_, :W_]; M2s = m.MM2s[g][:, :H_]; M2b = m.MM2b[g][:, :H_]
        l1w = m.Mln1w[g][:, :H_]; l1b = m.Mln1b[g][:, :H_]; l2w = m.Mln2w[g][:, :H_]; l2b = m.Mln2b[g][:, :H_]
        Hw = m.MHw[g][:, :H_]; MF = m.MF[g][:, :W_]; Hb = m.MHb[g]; h = m.MH[g][:int(m.MLd[g]), :H_]
        assert Gs.strides == Gb.strides and M1s.strides == M1b.strides and M2s.strides == M2b.strides
        assert l1w.strides == l1b.strides == l2w.strides == l2b.strides and m.MLAST.shape[1] == PT.shape[0]
        PTq, PTs = q16(PT) if PT16 else (PT, None)
        I += [H_, W_, h.shape[0], int(m.Mmix[g]), int(m.Mncol[g]), int(m.mfold) | (2 * int(m.Msgn[g])),
              P(PTq), PTq.strides[0] // PTq.itemsize, P(m.Mcols[g]), P(m.Mpb[g])] + ([P(PTs)] if PT16 else []) + [
              P(Gw), Gw.strides[0], Gw.strides[1], P(Gs), P(Gb), Gs.strides[0] // 4,
              P(M1w), M1w.strides[0], M1w.strides[1], P(M1s), P(M1b), M1s.strides[0] // 4,
              P(M2w), M2w.strides[0], M2w.strides[1], P(M2s), P(M2b), M2s.strides[0] // 4,
              P(l1w), P(l1b), P(l2w), P(l2b), l1w.strides[0] // 4,
              P(Hw), Hw.strides[0] // 4, P(MF), MF.strides[0] // 4, P(Hb),
              m.MLAST.shape[1], h.strides[0] // 4]
        keep += [PTq, PTs, PT, Gw, Gs, Gb, M1w, M1s, M1b, M2w, M2s, M2b, l1w, l1b, l2w, l2b, Hw, MF, Hb, m.Mcols[g], m.Mpb[g]]
    def q8(W):   # int8 per output row (the minGRU members' scheme): (3H, H) float -> int8, scales
        W = np.asarray(W, np.float32); s_ = np.maximum(np.abs(W).max(1), 1e-12) / 127.0
        return np.ascontiguousarray(np.clip(np.round(W / s_[:, None]), -127, 127).astype(np.int8)), s_.astype(np.float32)
    for g in range(len(m.gru)):   # GRU members (PyTorch 2-layer, dc head): recurrent + layer-2 weights int8 per row
        R0q, R0s = q8(m.GR0[g]); W1q, W1s = q8(m.GW1[g]); R1q, R1s = q8(m.GR1[g])
        W0T = m.W0T[g]; H_ = int(m.GR0[g].shape[1]); Wh = np.ascontiguousarray(m.GWh[g], np.float32)
        assert W0T.shape[1] == 3 * H_ and W0T.flags.c_contiguous and Wh.shape == (2, H_)
        arrs = [m.Gb0[g], m.Gc0[g], m.Gb1[g], m.Gc1[g], Wh, m.Gbh[g]]
        arrs = [np.ascontiguousarray(a_, np.float32) for a_ in arrs]
        W0q, W0s = q16(W0T) if PT16 else (W0T, None)
        I += [H_, int(m.ncol[g]), P(W0q), W0q.shape[1], P(m.cols[g])] + ([P(W0s)] if PT16 else []) + [P(a_) for a_ in arrs] +              [P(R0q), P(R0s), P(W1q), P(W1s), P(R1q), P(R1s), W0T.shape[0]]
        keep += [W0q, W0s, W0T, m.cols[g], R0q, R0s, W1q, W1s, R1q, R1s] + arrs
    assert len(m.beta0) == m.NM + 1
    return np.array(I, np.int64), np.r_[m.beta0, m.beta1, m.scale].astype(np.float64), (m, keep)


def _rowc_rows(n=400):
    """deterministic test rows: noisy, with runs of unchanged columns and missing-value sentinels"""
    r = np.random.default_rng(0); X = np.cumsum(r.normal(0, 0.05, (n, 112)) * (r.random((n, 112)) < 0.3), 0).astype(np.float32)
    X[r.random((n, 112)) < 0.02] = SENT; return X


_ROWC_CHILD = r"""
import os, sys, importlib.util, numpy as np
os.environ["WNN_ROWC_CHILD"] = "1"
sp = importlib.util.spec_from_file_location("solution_child", os.path.join(sys.argv[1], "solution.py"))
S = importlib.util.module_from_spec(sp); sp.loader.exec_module(S)
m = S.PredictionModel(); st = S._load_rowc(sys.argv[2]).new(*S._rowc_cfg(m))
np.save(sys.argv[3], st.run_seq(S._rowc_rows())); print("OK")
"""


class PredictionModel:
    def __init__(self):
        w = np.load(HERE / "weights.npz")
        self.w = {k: w[k] for k in w.files}
        if os.environ.get("WNN_PT16", "1") == "1":   # PT16: projection weights rounded to int16 per input column, every path
            for k in list(self.w):
                if (k[0] == "m" and k.endswith("_PT")) or (k[0] == "g" and k.endswith("_W0")):
                    A = np.asarray(self.w[k], np.float32); ax = 1 if k.endswith("_PT") else 0
                    s_ = (np.maximum(np.abs(A).max(ax, keepdims=True), 1e-30) / 32767.0).astype(np.float32)
                    self.w[k] = (np.round(A / s_) * s_).astype(np.float32)
        g = self.w
        self.gru_names = [str(v) for v in g["gru_names"]]; self.gru = []
        for i in range(len(self.gru_names)):
            self.gru.append([g[f"g{i}_{k}"] for k in ("W0", "b0", "R0", "c0", "W1", "b1", "R1", "c1", "Wh", "bh")])
        self.sc = g["sent_cols_gru"]
        self.w1 = [g[f"w1_{k}"] for k in ("W0", "b0", "W1", "b1", "W2", "b2", "W3", "b3")]
        self.w1_mu = g["w1_mu"]; self.w1_isd = g["w1_inv_sd"]
        self.trees = [[g[f"t{k}_{a}"] for a in ("feat", "thr", "left", "right", "leafv", "roots")] for k in range(2)]
        self.beta = [g["beta0"], g["beta1"]]; self.scale = float(g["scale"])
        self.pca = (g["pca_mub"], g["pca_vb"], float(g["pca_sdb"]), g["pca_mua"], g["pca_va"], float(g["pca_sda"]))
        self.KS = np.array([10, 50, 200, 1000], np.int64); self.SLOW = np.array([107, 39, 26], np.int64)
        H = 128; NF = self.w1_mu.shape[0]
        self.inp = np.zeros(229, np.float32); self.prev = np.zeros(112, np.float32)
        self.gst = [(np.zeros(H, np.float32), np.zeros(H, np.float32), np.zeros(3 * H, np.float32), np.zeros(3 * H, np.float32),
                     np.zeros(2, np.float32)) for _ in range(len(self.gru))]
        self.f = np.zeros(NF, np.float32); self.fn = np.zeros(NF, np.float32); self.xc = np.zeros(112, np.float32)
        self.wprev = np.zeros(112, np.float32); self.m3 = np.zeros((3, 112)); self.since = np.zeros(13); self.act = np.zeros((2, 13))
        self.femas = np.zeros(16); self.gap_e = np.zeros(1); self.mq = np.zeros((4, 112))
        self.h = [np.zeros(self.w1[0].shape[0], np.float32), np.zeros(self.w1[2].shape[0], np.float32), np.zeros(self.w1[4].shape[0], np.float32)]
        self.w1out = np.zeros(2, np.float32)
        self.e2 = np.zeros(52); self.sf = np.zeros(18); self.si = np.zeros(9, np.int64)
        self.ring_m = np.zeros(1001); self.ring_t = np.zeros(1001, np.int64); self.gaps = np.zeros(8)
        self.cnt = np.zeros((3, 20001)); self.last = np.zeros((3, 20001), np.int64)
        self.osum = np.zeros((2, 20001)); self.on = np.zeros((2, 20001))
        self.slot_hist = np.zeros(20001, np.int64); self.m_hist = np.zeros(20001)
        # minGRU members (all of one shape: H hidden, L layers)
        self.mg_names = [str(v) for v in g["mg_names"]] if "mg_names" in g else []
        MN = len(self.mg_names)
        self.mfid = np.asarray(g["mg_feats"], np.int64) if MN else np.zeros(0, np.int64)
        if MN:
            ks = ("PT", "pb", "ln1w", "ln1b", "Gw", "Gb", "ln2w", "ln2b", "M1w", "M1b", "M2w", "M2b", "Hw", "Hb")
            ms = [{k: g[f"m{i}_{k}"] for k in ks} for i in range(MN)]
            ML_ = max(m_["ln1w"].shape[0] for m_ in ms)   # DEPTH: members may differ in depth; padded layers are never run
            self.MLd = np.array([m_["ln1w"].shape[0] for m_ in ms], np.int64)
            self.MHd = np.array([m_["pb"].shape[0] for m_ in ms], np.int64); self.MWd = np.array([m_["M1w"].shape[1] for m_ in ms], np.int64)
            MH_, MW_ = int(self.MHd.max()), int(self.MWd.max()); NIm = max(m_["PT"].shape[0] for m_ in ms)
            def _pad(a, shape):
                out_ = np.zeros(shape, a.dtype); out_[tuple(slice(0, d) for d in a.shape)] = a; return out_
            HOm = max(m_["Hw"].shape[0] for m_ in ms)
            for i, m_ in enumerate(ms):      # MIXW: pad to the widest member (padding is never read: each member uses views)
                tgt = {"pb": (MH_,), "ln1w": (ML_, MH_), "ln1b": (ML_, MH_), "ln2w": (ML_, MH_), "ln2b": (ML_, MH_), "Gw": (ML_, 2 * MH_, MH_),
                       "Gb": (ML_, 2 * MH_), "M1w": (ML_, MW_, MH_), "M1b": (ML_, MW_), "M2w": (ML_, MH_, MW_), "M2b": (ML_, MH_), "Hw": (m_["Hw"].shape[0], MH_)}
                for k_, sh_ in tgt.items(): m_[k_] = _pad(np.asarray(m_[k_]), sh_)
                m_["PT"] = _pad(np.asarray(m_["PT"]), (m_["PT"].shape[0], MH_))
            PT = np.zeros((MN, NIm, MH_), np.float32)
            for i, m_ in enumerate(ms): PT[i, :m_["PT"].shape[0]] = m_["PT"]
            self.MPT = np.ascontiguousarray(PT)
            HO = max(m_["Hw"].shape[0] for m_ in ms)      # heads differ in size (D/C head: 2, mixture head: 3K) -> pad
            for m_ in ms:
                if m_["Hw"].shape[0] < HO:
                    m_["Hw"] = np.vstack([m_["Hw"], np.zeros((HO - m_["Hw"].shape[0], m_["Hw"].shape[1]), np.float32)]); m_["Hb"] = np.r_[m_["Hb"], np.zeros(HO - len(m_["Hb"]), np.float32)]
            self.Mmix = np.array([int(g[f"m{i}_mix"]) if f"m{i}_mix" in g else 0 for i in range(MN)], np.int64)
            self.Msgn = np.array([int(g[f"m{i}_sgn"]) if f"m{i}_sgn" in g else 0 for i in range(MN)], np.int64)   # BIGSWARM signed
            stk = lambda k: np.ascontiguousarray(np.stack([m_[k] for m_ in ms]).astype(np.float32))
            (self.Mpb, self.Mln1w, self.Mln1b, self.MGw, self.MGb, self.Mln2w, self.Mln2b, self.MM1w, self.MM1b, self.MM2w, self.MM2b,
             self.MHw, self.MHb) = (stk(k) for k in ks[1:])
            self.mquant = "m0_Gs" in g                      # 8-bit weights: int8 matrices + one float32 scale per output row
            if self.mquant:
                QSH = {"Gw": (ML_, 2 * MH_, MH_), "M1w": (ML_, MW_, MH_), "M2w": (ML_, MH_, MW_), "Gs": (ML_, 2 * MH_), "M1s": (ML_, MW_), "M2s": (ML_, MH_)}
                qs = lambda k: np.ascontiguousarray(np.stack([_pad(np.asarray(g[f"m{i}_{k}"]), QSH[k]) for i in range(MN)]))
                self.MGw, self.MM1w, self.MM2w = qs("Gw").astype(np.int8), qs("M1w").astype(np.int8), qs("M2w").astype(np.int8)
                self.MGs, self.MM1s, self.MM2s = qs("Gs").astype(np.float32), qs("M1s").astype(np.float32), qs("M2s").astype(np.float32)
            else:
                self.MGs = np.ones(self.MGb.shape, np.float32); self.MM1s = np.ones(self.MM1b.shape, np.float32); self.MM2s = np.ones(self.MM2b.shape, np.float32)
            # HEADFOLD: the last layer's MLP output only feeds the head, so Hw (u + M2 g + b2) = Hw u + F g + Hw b2 with
            # F = Hw diag(M2s) M2w (one small matrix instead of a 2H x H product per row; exact algebra, minus one rounding)
            self.mfold = 1 if (USE_C and self.mquant) else 0
            self.MF = np.zeros((MN, self.MHw.shape[1], MW_), np.float32)
            if self.mfold:
                for i in range(MN):
                    H_, W_ = int(self.MHd[i]), int(self.MWd[i]); Hw_ = self.MHw[i][:, :H_].astype(np.float64)
                    Lx = int(self.MLd[i]) - 1; M2_ = self.MM2w[i, Lx][:H_, :W_].astype(np.float64) * self.MM2s[i, Lx][:H_, None].astype(np.float64)
                    self.MF[i][:, :W_] = (Hw_ @ M2_).astype(np.float32)
                    self.MHb[i] = (self.MHb[i].astype(np.float64) + Hw_ @ self.MM2b[i, Lx][:H_].astype(np.float64)).astype(np.float32)
            self.Mcols = np.zeros((MN, NIm), np.int64); self.Mncol = np.zeros(MN, np.int64)
            for i, m_ in enumerate(ms):
                used = np.nonzero(np.abs(m_["PT"]).sum(1) > 0)[0]; self.Mncol[i] = len(used); self.Mcols[i, :len(used)] = used
        else:
            MH_, ML_, NIm, MW_ = 1, 1, 1, 2; self.MHd = np.zeros(0, np.int64); self.MWd = np.zeros(0, np.int64); self.MLd = np.zeros(0, np.int64)
            self.MPT = np.zeros((0, 1, 1), np.float32); self.Mpb = np.zeros((0, 1), np.float32)
            self.Mln1w = self.Mln1b = self.Mln2w = self.Mln2b = np.zeros((0, 1, 1), np.float32)
            self.MGw = self.MM1w = self.MM2w = np.zeros((0, 1, 1, 1), np.float32); self.MGb = self.MM1b = self.MM2b = np.zeros((0, 1, 1), np.float32)
            self.MHw = np.zeros((0, 2, 1), np.float32); self.MHb = np.zeros((0, 2), np.float32)
            self.MGs = self.MM1s = self.MM2s = np.zeros((0, 1, 1), np.float32); self.Mmix = np.zeros(0, np.int64)
            self.MF = np.zeros((0, 2, 1), np.float32); self.mfold = 0; self.Msgn = np.zeros(0, np.int64)
            self.Mcols = np.zeros((0, 1), np.int64); self.Mncol = np.zeros(0, np.int64)
        self.MPX = np.zeros((MN, MH_), np.float64); self.MLAST = np.zeros((MN, NIm), np.float32); self.MH = np.zeros((MN, ML_, MH_), np.float32)
        self.Mu = np.zeros(MH_, np.float32); self.Mt1 = np.zeros(MH_, np.float32); self.Mg2 = np.zeros(max(2 * MH_, MW_, 64), np.float32); self.Mt3 = np.zeros(MH_, np.float32); self.PM = np.zeros((MN, 2), np.float32)
        self.use_corr = bool(len(self.trees[0][0]) or len(self.trees[1][0]))
        self.use_win = bool(int(g["use_win"])) if "use_win" in g else True
        # PRESENT heads (per minGRU; size 0 = none): first layer transposed (inputs x P), kept incrementally like the projection
        PS = [int(g[f"m{i}_QW1"].shape[0]) if f"m{i}_QW1" in g else 0 for i in range(MN)]; PP = max(PS + [1]); NQ = max(NIm, 1)
        self.MPres = np.array(PS, np.int64); self.MQT = np.zeros((MN, NQ, PP), np.float32); self.MQb1 = np.zeros((MN, PP), np.float32)
        self.MQW2 = np.zeros((MN, 2, PP), np.float32); self.MQb2 = np.zeros((MN, 2), np.float32)
        for i in range(MN):
            if PS[i]:
                w1_ = g[f"m{i}_QW1"]; self.MQT[i, :w1_.shape[1], :PS[i]] = w1_.T; self.MQb1[i, :PS[i]] = g[f"m{i}_QB1"]
                self.MQW2[i, :, :PS[i]] = g[f"m{i}_QW2"]; self.MQb2[i] = g[f"m{i}_QB2"]
        self.MQX = np.zeros((MN, PP), np.float64); self.MQLAST = np.zeros((MN, NQ), np.float32); self.Mq = np.zeros(PP, np.float32)
        self.NM = len(self.gru) + MN + 1
        self.xp = np.zeros(112, np.float32); self.z = np.zeros(self.NM + 52)
        self.cur = None; self.t = 0
        # stacked GRU weights for the fused kernel: transposed input weights + each model's used input columns
        Gn = len(self.gru); NI = max([W[0].shape[1] for W in self.gru] + [max(self.MPT.shape[1], 229) if MN else 229])
        self.fid = np.asarray(g["gru_feats"], np.int64) if "gru_feats" in g else np.zeros(Gn, np.int64)
        self.has_reg = bool((self.fid == 1).any())
        G3 = self.gru[0][0].shape[0] if Gn else 3 * H
        W0T = np.zeros((Gn, NI, G3), np.float32)
        for i, W in enumerate(self.gru): W0T[i, :W[0].shape[1]] = W[0].T
        self.W0T = np.ascontiguousarray(W0T)
        self.GXIN = np.zeros((Gn, G3), np.float64); self.LAST = np.zeros((Gn, NI), np.float32)
        self.inp2 = np.zeros(NI, np.float32); self.xr = np.zeros(112); self.prevr = np.zeros(112); self.rates = np.zeros(4)
        self.m500 = np.zeros(22); self.m2000 = np.zeros(22); self.held = np.zeros(22)
        self.med_r = np.asarray(g["med"], np.float32); self.lo_r = np.asarray(g["lo"], np.float32); self.hi_r = np.asarray(g["hi"], np.float32)
        self.cols = np.zeros((Gn, NI), np.int64); self.ncol = np.zeros(Gn, np.int64)
        for i, W in enumerate(self.gru):
            used = np.nonzero(np.abs(W[0]).sum(0) > 0)[0]; self.ncol[i] = len(used); self.cols[i, :len(used)] = used
        shapes = [(3 * H,), (3 * H, H), (3 * H,), (3 * H, H), (3 * H,), (3 * H, H), (3 * H,), (2, H), (2,)]
        st = lambda j: np.ascontiguousarray(np.stack([W[j] for W in self.gru])) if Gn else np.zeros((0,) + shapes[j - 1], np.float32)
        self.Gb0, self.GR0, self.Gc0, self.GW1, self.Gb1, self.GR1, self.Gc1, self.GWh, self.Gbh = (st(j) for j in range(1, 10))
        self.H0 = np.zeros((Gn, H), np.float32); self.H1 = np.zeros((Gn, H), np.float32); self.PG = np.zeros((Gn, 2), np.float32)
        self.gxf = np.zeros(3 * H, np.float32); self.tmpf = np.zeros(3 * H, np.float32); self.outf = np.zeros(2, np.float32)
        self.beta0 = np.asarray(self.beta[0], np.float64); self.beta1 = np.asarray(self.beta[1], np.float64)
        self.rowc = "off"
        if os.environ.get("WNN_ROWC_CHILD") != "1" and _rowc_supported(self):
            try: self._rowc_setup()
            except Exception as e: self.rowc = f"failed: {type(e).__name__}"

    def _rowc_setup(self):
        """ROWC: build the C row engine, prove in a CHILD process that it runs (a crash there cannot hurt this one), check
        its outputs against this package's own Numba path on 400 test rows, then bind it as self.predict."""
        so = _build_rowc()
        if so is None: self.rowc = "unavailable"; return
        import sys as _sys
        ref = os.path.join(os.path.dirname(so), "child_out.npy")
        r = subprocess.run([_sys.executable, "-c", _ROWC_CHILD, str(HERE), so, ref], capture_output=True, text=True, timeout=600)
        if r.returncode != 0 or "OK" not in r.stdout: self.rowc = "child failed"; return
        X = _rowc_rows(); out_nb = np.zeros((len(X), 2), np.float32)
        self.cur = None; self._reset()
        if not hasattr(self, "bufs"): self._pack()
        self._ob = self._objs()
        for t in range(len(X)): out_nb[t] = self.step_packed(X[t])
        self._reset(); self.cur = None
        st = _load_rowc(so).new(*_rowc_cfg(self)); out_c = st.run_seq(X); out_child = np.load(ref)
        d = np.abs(out_c - out_nb)
        if not (np.allclose(out_c, out_child, rtol=0, atol=1e-5) and np.isfinite(out_c).all() and d.max() < 0.1 and d.mean() < 5e-3):   # VECACT differs a little from Numba's tables; a broken config is >> this
            self.rowc = f"mismatch (max {d.max():.2e}, mean {d.mean():.2e})"; return
        st.run_seq(X[:1]); self._stepper = st; self.predict = st.predict; self.rowc = f"on (max diff vs Numba {d.max():.1e})"

    def _reset(self):
        for st in self.gst:
            st[0].fill(0.0); st[1].fill(0.0)
        self.H0.fill(0.0); self.H1.fill(0.0)
        self.sf.fill(0.0); self.si.fill(0); self.ring_m.fill(0.0); self.ring_t.fill(0); self.gaps.fill(0.0)
        self.cnt.fill(0.0); self.last.fill(0); self.osum.fill(0.0); self.on.fill(0.0); self.slot_hist.fill(0)
        self.d = [Dict.empty(key_type=types.int64, value_type=types.int64) for _ in range(3)]
        self.t = 0

    def step(self, x):
        """Advance every model by one row; returns the final (2,) prediction. (Reference path; raw_d1 GRUs only.)"""
        assert not self.has_reg and not len(self.mg_names), "use step_fast for packages with reg GRUs or minGRUs"
        t = self.t; first = t == 0
        build_raw_d1(x, self.prev, first, self.inp, self.sc)
        for W, st in zip(self.gru, self.gst):
            gru_step(self.inp, W[0], W[1], W[2], W[3], W[4], W[5], W[6], W[7], W[8], W[9], st[0], st[1], st[2], st[3], st[4])
        w1d_feat_row(x, first, self.f, self.xc, self.wprev, self.m3, self.since, self.act, self.femas, self.gap_e, self.mq,
                     self.w["sent_cols"], self.w["zero_cols"], self.w["med"], self.w["lo"], self.w["hi"], self.w["groups"])
        W = self.w1
        mlp_row(self.f, self.w1_mu, self.w1_isd, self.fn, W[0], W[1], W[2], W[3], W[4], W[5], W[6], W[7], self.h[0], self.h[1], self.h[2], self.w1out)
        evt2_step(x, self.xp, t, self.e2, self.sf, self.si, self.ring_m, self.ring_t, self.gaps, self.cnt, self.last, self.osum,
                  self.on, self.slot_hist, self.m_hist, self.d[0], self.d[1], self.d[2], *self.pca, self.KS, self.SLOW)
        self.xp[:] = x; self.t = t + 1
        out = np.empty(2, np.float32)
        p = [st[4] for st in self.gst] + [self.w1out]; NM = self.NM
        for k in range(2):
            b = self.beta[k]; base = b[NM]
            for i in range(NM):
                base += b[i] * p[i][k]; self.z[i] = p[i][k]
            self.z[NM:] = self.e2
            T = self.trees[k]
            out[k] = (base + trees_predict(self.z, T[0], T[1], T[2], T[3], T[4], T[5])) * self.scale
        return out

    def step_fast(self, x):
        """Same as step(), in one fused Numba call."""
        T0, T1 = self.trees; W = self.w1; g = self.w
        step_all(x, self.t, self.inp, self.prev, self.sc, self.fid, self.has_reg, self.inp2, self.xr, self.prevr, self.rates,
                 self.m500, self.m2000, self.held, self.med_r, self.lo_r, self.hi_r, g["sent_cols"], g["zero_cols"],
                 self.W0T, self.ncol, self.cols, self.Gb0, self.GR0, self.Gc0, self.GW1, self.Gb1, self.GR1, self.Gc1, self.GWh, self.Gbh,
                 self.H0, self.H1, self.gxf, self.tmpf, self.PG, self.GXIN, self.LAST,
                 self.mfid, self.MPT, self.Mncol, self.Mcols, self.Mpb, self.MPX, self.MLAST, self.Mln1w, self.Mln1b, self.MGw, self.MGs, self.MGb,
                 self.Mln2w, self.Mln2b, self.MM1w, self.MM1s, self.MM1b, self.MM2w, self.MM2s, self.MM2b, self.MHw, self.MHb, self.Mmix, self.MF, self.mfold, self.Msgn, self.MH, self.Mu, self.Mt1, self.Mg2, self.Mt3, self.PM, self.MHd, self.MWd, self.MLd,
                 self.MPres, self.MQT, self.MQb1, self.MQW2, self.MQb2, self.MQX, self.MQLAST, self.Mq, self.use_win, self.use_corr,
                 self.f, self.xc, self.wprev, self.m3, self.since, self.act, self.femas, self.gap_e, self.mq,
                 g["sent_cols"], g["zero_cols"], g["med"], g["lo"], g["hi"], g["groups"],
                 self.w1_mu, self.w1_isd, self.fn, W[0], W[1], W[2], W[3], W[4], W[5], W[6], W[7], self.h[0], self.h[1], self.h[2], self.w1out,
                 self.xp, self.e2, self.sf, self.si, self.ring_m, self.ring_t, self.gaps, self.cnt, self.last, self.osum, self.on,
                 self.slot_hist, self.m_hist, self.d[0], self.d[1], self.d[2], *self.pca, self.KS, self.SLOW,
                 self.beta0, self.beta1, self.scale, self.z, *T0, *T1, self.outf)
        self.t += 1
        return self.outf

    # ---------------------------------------------------------------- argument packing (speed)
    # Calling a Numba function costs ~45 ns per argument (step_all has ~138: ~6 us per row). All arrays are therefore
    # moved into a few flat buffers (one per dtype) and the model's attributes are re-pointed to views of them; a generated
    # wrapper takes (x, t, the buffers, a descriptor table, the few non-array arguments) and rebuilds the views inside
    # compiled code. Same computation, same memory, ~0.2 us call cost.
    def _static_args(self):
        """everything step_all takes after (x, t), in its parameter order."""
        T0, T1 = self.trees; W = self.w1; g = self.w
        return (self.inp, self.prev, self.sc, self.fid, self.has_reg, self.inp2, self.xr, self.prevr, self.rates,
                self.m500, self.m2000, self.held, self.med_r, self.lo_r, self.hi_r, g["sent_cols"], g["zero_cols"],
                self.W0T, self.ncol, self.cols, self.Gb0, self.GR0, self.Gc0, self.GW1, self.Gb1, self.GR1, self.Gc1, self.GWh, self.Gbh,
                self.H0, self.H1, self.gxf, self.tmpf, self.PG, self.GXIN, self.LAST,
                self.mfid, self.MPT, self.Mncol, self.Mcols, self.Mpb, self.MPX, self.MLAST, self.Mln1w, self.Mln1b, self.MGw, self.MGs, self.MGb,
                self.Mln2w, self.Mln2b, self.MM1w, self.MM1s, self.MM1b, self.MM2w, self.MM2s, self.MM2b, self.MHw, self.MHb, self.Mmix, self.MF, self.mfold, self.Msgn, self.MH, self.Mu, self.Mt1, self.Mg2, self.Mt3, self.PM, self.MHd, self.MWd, self.MLd,
                self.MPres, self.MQT, self.MQb1, self.MQW2, self.MQb2, self.MQX, self.MQLAST, self.Mq, self.use_win, self.use_corr,
                self.f, self.xc, self.wprev, self.m3, self.since, self.act, self.femas, self.gap_e, self.mq,
                g["sent_cols"], g["zero_cols"], g["med"], g["lo"], g["hi"], g["groups"],
                self.w1_mu, self.w1_isd, self.fn, W[0], W[1], W[2], W[3], W[4], W[5], W[6], W[7], self.h[0], self.h[1], self.h[2], self.w1out,
                self.xp, self.e2, self.sf, self.si, self.ring_m, self.ring_t, self.gaps, self.cnt, self.last, self.osum, self.on,
                self.slot_hist, self.m_hist, self.d[0], self.d[1], self.d[2], *self.pca, self.KS, self.SLOW,
                self.beta0, self.beta1, self.scale, self.z, *T0, *T1, self.outf)

    def _pack(self):
        import inspect
        names = list(inspect.signature(step_all.py_func).parameters)[2:]
        vals = self._static_args(); assert len(names) == len(vals)
        kinds = [np.float32, np.float64, np.int64, np.int8]
        groups = {k: [] for k in kinds}; seen = {}; spec = []; nobj = 0
        for v in vals:
            if isinstance(v, np.ndarray) and v.dtype.type in groups and v.ndim <= 4:
                if id(v) not in seen:
                    seen[id(v)] = (kinds.index(v.dtype.type), len(groups[v.dtype.type])); groups[v.dtype.type].append(v)
                spec.append(("a",) + seen[id(v)] + (v.ndim,))
            else:
                spec.append(("o", nobj)); nobj += 1
        bufs, desc, views = [], [], {}
        for ki, k in enumerate(kinds):
            arrs = groups[k]; tot = sum(a.size for a in arrs); buf = np.zeros(max(tot, 1), k); off = 0; d_ = np.zeros((max(len(arrs), 1), 6), np.int64)
            for ai, a in enumerate(arrs):
                buf[off:off + a.size] = a.ravel(); sh = list(a.shape) + [1] * (4 - a.ndim)
                d_[ai] = [off] + sh + [a.size]; views[id(a)] = buf[off:off + a.size].reshape(a.shape); off += a.size
            bufs.append(buf); desc.append(d_)
        def swap(o):   # re-point every attribute (also inside lists / tuples / dicts) to the packed views
            if isinstance(o, np.ndarray): return views.get(id(o), o)
            if isinstance(o, list): return [swap(e) for e in o]
            if isinstance(o, tuple): return tuple(swap(e) for e in o)
            if isinstance(o, dict): return {k_: swap(e) for k_, e in o.items()}
            return o
        for k_, v in list(self.__dict__.items()):
            if k_ not in ("w",): self.__dict__[k_] = swap(v)
        self.w = {k_: swap(v) for k_, v in self.w.items()}
        self.bufs, self.desc, self.spec = bufs, desc, spec
        bn = ["F32", "F64", "I64", "I8"]; lines = []; args = []
        # SPEED2: with the corrector off its typed dicts are never read - make them inside the kernel instead of
        # unboxing three Python objects on every row (~2.9 us); and clip the output inside the kernel (np.clip ~3 us)
        ovals = [v for v, sp in zip(vals, spec) if sp[0] == "o"]
        self._drop_o = {j for j, v in enumerate(ovals) if (not self.use_corr) and type(v).__name__ == "Dict"}
        for i, sp in enumerate(spec):
            if sp[0] == "o":
                args.append("_ED()" if sp[1] in self._drop_o else f"o{sp[1]}")
            else:
                ki, ai, nd = sp[1], sp[2], sp[3]; D = f"D{ki}"
                shp = ", ".join(f"{D}[{ai}, {1 + j}]" for j in range(nd))
                lines.append(f"    a{i} = {bn[ki]}[{D}[{ai}, 0]:{D}[{ai}, 0] + {D}[{ai}, 5]].reshape(({shp},))"); args.append(f"a{i}")
        NL = chr(10)
        keep = [j for j in range(nobj) if j not in self._drop_o]
        src = ("def step_packed(x, t, F32, F64, I64, I8, D0, D1, D2, D3" + "".join(f", o{j}" for j in keep) + "):" + NL +
               NL.join(lines) + NL + "    step_all(x, t, " + ", ".join(args) + ")" + NL +
               f"    o_ = {args[-1]}" + NL + "    for k_ in range(o_.shape[0]): o_[k_] = min(np.float32(2.0), max(np.float32(-2.0), o_[k_]))" + NL)
        ns = {"step_all": step_all, "np": np, "_ED": _ED}; exec(src, ns); self._step_packed = njit(ns["step_packed"])
        self._objs_names = None

    def _objs(self):
        vals = self._static_args(); ov = [v for v, sp in zip(vals, self.spec) if sp[0] == "o"]
        return tuple(v for j, v in enumerate(ov) if j not in getattr(self, "_drop_o", set()))

    def step_packed(self, x):
        b, d = self.bufs, self.desc
        self._step_packed(x, self.t, b[0], b[1], b[2], b[3], d[0], d[1], d[2], d[3], *self._ob)
        self.t += 1
        return self.outf

    def predict(self, data_point):
        seq = int(data_point.seq_ix)
        if seq != self.cur:
            if int(data_point.step_in_seq) != 0:
                raise ValueError("a new sequence must start at step zero")
            self.cur = seq; self._reset()
            if not hasattr(self, "bufs"): self._pack()
            self._ob = self._objs()          # the typed dicts are recreated by _reset
        x = np.asarray(data_point.state, dtype=np.float32)
        out = self.step_packed(x)
        if not data_point.need_prediction:
            return None
        return out.copy()   # SPEED2: already clipped to [-2, 2] (float32) inside the kernel

if __name__ == "__main__":
    import argparse, sys
    sys.path.insert(0, str(HERE.parents[1] / "wnn_connectome_starterpack"))
    from utils import ScorerStepByStep
    ap = argparse.ArgumentParser(); ap.add_argument("--validation", required=True)
    print(ScorerStepByStep(ap.parse_args().validation).score(PredictionModel()))
